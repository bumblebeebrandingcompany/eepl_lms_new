<?php $__env->startSection('content'); ?>
<div class="row mb-2">
   <div class="col-sm-6">
        <h2>
		<?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.project.title_singular')); ?>

        </h2>
   </div>
</div>
<div class="card card-primary card-outline">
    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.projects.update", [$project->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="name"><?php echo e(trans('cruds.project.fields.name')); ?></label>
                <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name" id="name" value="<?php echo e(old('name', $project->name)); ?>" required>
                <?php if($errors->has('name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.project.fields.name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="start_date"><?php echo e(trans('cruds.project.fields.start_date')); ?></label>
                <input class="form-control date <?php echo e($errors->has('start_date') ? 'is-invalid' : ''); ?>" type="text" name="start_date" id="start_date" value="<?php echo e(old('start_date', $project->start_date)); ?>">
                <?php if($errors->has('start_date')): ?>
                    <span class="text-danger"><?php echo e($errors->first('start_date')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.project.fields.start_date_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="end_date"><?php echo e(trans('cruds.project.fields.end_date')); ?></label>
                <input class="form-control date <?php echo e($errors->has('end_date') ? 'is-invalid' : ''); ?>" type="text" name="end_date" id="end_date" value="<?php echo e(old('end_date', $project->end_date)); ?>">
                <?php if($errors->has('end_date')): ?>
                    <span class="text-danger"><?php echo e($errors->first('end_date')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.project.fields.end_date_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="client_id"><?php echo e(trans('cruds.project.fields.client')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('client') ? 'is-invalid' : ''); ?>" name="client_id" id="client_id" required>
                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((old('client_id') ? old('client_id') : $project->client->id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('client')): ?>
                    <span class="text-danger"><?php echo e($errors->first('client')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.project.fields.client_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="location"><?php echo e(trans('cruds.project.fields.location')); ?></label>
                <input class="form-control <?php echo e($errors->has('location') ? 'is-invalid' : ''); ?>" type="text" name="location" id="location" value="<?php echo e(old('location', $project->location)); ?>">
                <?php if($errors->has('location')): ?>
                    <span class="text-danger"><?php echo e($errors->first('location')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.project.fields.location_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="description"><?php echo e(trans('cruds.project.fields.description')); ?></label>
                <textarea class="form-control ckeditor <?php echo e($errors->has('description') ? 'is-invalid' : ''); ?>" name="description" id="description"><?php echo old('description', $project->description); ?></textarea>
                <?php if($errors->has('description')): ?>
                    <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.project.fields.description_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function () {
  function SimpleUploadAdapter(editor) {
    editor.plugins.get('FileRepository').createUploadAdapter = function(loader) {
      return {
        upload: function() {
          return loader.file
            .then(function (file) {
              return new Promise(function(resolve, reject) {
                // Init request
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo e(route('admin.projects.storeCKEditorImages')); ?>', true);
                xhr.setRequestHeader('x-csrf-token', window._token);
                xhr.setRequestHeader('Accept', 'application/json');
                xhr.responseType = 'json';

                // Init listeners
                var genericErrorText = `Couldn't upload file: ${ file.name }.`;
                xhr.addEventListener('error', function() { reject(genericErrorText) });
                xhr.addEventListener('abort', function() { reject() });
                xhr.addEventListener('load', function() {
                  var response = xhr.response;

                  if (!response || xhr.status !== 201) {
                    return reject(response && response.message ? `${genericErrorText}\n${xhr.status} ${response.message}` : `${genericErrorText}\n ${xhr.status} ${xhr.statusText}`);
                  }

                  $('form').append('<input type="hidden" name="ck-media[]" value="' + response.id + '">');

                  resolve({ default: response.url });
                });

                if (xhr.upload) {
                  xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                      loader.uploadTotal = e.total;
                      loader.uploaded = e.loaded;
                    }
                  });
                }

                // Send request
                var data = new FormData();
                data.append('upload', file);
                data.append('crud_id', '<?php echo e($project->id ?? 0); ?>');
                xhr.send(data);
              });
            })
        }
      };
    }
  }

  var allEditors = document.querySelectorAll('.ckeditor');
  for (var i = 0; i < allEditors.length; ++i) {
    ClassicEditor.create(
      allEditors[i], {
        extraPlugins: [SimpleUploadAdapter]
      }
    );
  }
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/projects/edit.blade.php ENDPATH**/ ?>