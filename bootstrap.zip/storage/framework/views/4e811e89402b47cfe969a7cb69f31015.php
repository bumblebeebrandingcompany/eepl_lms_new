<div class="row">
    <div class="col-sm-12 d-flex justify-content-between align-items-center">
        <h2>
            <?php echo e(trans('cruds.lead.title_singular')); ?> <?php echo e(trans('global.list')); ?>

        </h2>
        <div class="cta">
            <div class="btn-group btn-group-toggle mr-2" data-toggle="buttons">
                <label class="btn btn-outline-secondary <?php if($lead_view == 'list'): ?> active <?php endif; ?>">
                    <input type="radio" name="toggle_view" class="toggle_view" id="list" value="list" <?php if($lead_view == 'list'): ?> checked <?php endif; ?>>
                    <?php echo app('translator')->get('messages.list_view'); ?>
                </label>
                <label class="btn btn-outline-secondary <?php if($lead_view == 'kanban'): ?> active <?php endif; ?>">
                    <input type="radio" name="toggle_view" class="toggle_view" id="kanban" value="kanban" <?php if($lead_view == 'kanban'): ?> checked <?php endif; ?>>
                    <?php echo app('translator')->get('messages.kanban_view'); ?>
                </label>
            </div>
            <?php if(auth()->user()->checkPermission('lead_create')): ?>
                <a class="btn btn-success float-right" href="<?php echo e(route('admin.leads.create')); ?>">
                    <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.lead.title_singular')); ?>

                </a>
            <?php endif; ?>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="card card-primary card-outline">
            <div class="card-body">
                <div class="row">
                    <?php if(!(auth()->user()->is_agency || auth()->user()->is_channel_partner || auth()->user()->is_channel_partner_manager)): ?>
                        <div class="col-md-3">
                            <label for="project_id">
                                <?php echo app('translator')->get('messages.projects'); ?>
                            </label>
                            <select class="search form-control" id="project_id">
                                <option value><?php echo e(trans('global.all')); ?></option>
                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php if(isset($filters['project_id']) && $filters['project_id'] == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    <?php endif; ?>
                    <?php if(auth()->user()->checkPermission('campaign_view')): ?>
                        <div class="col-md-3 campaigns_div">
                            <label for="campaign_id">
                                <?php echo app('translator')->get('messages.campaigns'); ?>
                            </label>
                            <select class="search form-control" id="campaign_id">
                                <option value><?php echo e(trans('global.all')); ?></option>
                                <?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php if(isset($filters['campaign_id']) && $filters['campaign_id'] == $item->id): ?> selected <?php endif; ?>><?php echo e($item->campaign_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    <?php endif; ?>
                    <?php if(auth()->user()->checkPermission('campaign_view')): ?>
                        <div class="col-md-3 sources_div">
                            <label for="source_id">
                                Source
                            </label>
                            <select class="search form-control select2" name="source" id="source_id">
                                <option value><?php echo e(trans('global.all')); ?></option>
                                <?php $__currentLoopData = $sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($source->id); ?>" <?php if(isset($filters['source']) && $filters['source'] == $item->id): ?> selected <?php endif; ?>><?php echo e($source->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    <?php endif; ?>
                    <div class="col-md-3">
                        <label for="added_on"><?php echo e(trans('messages.added_on')); ?></label>
                        <input class="form-control date_range" type="text" name="date" id="added_on" readonly>
                    </div>
                    <div class="col-md-3">
                        <label for="leads_status">
                            <?php echo app('translator')->get('messages.status'); ?>
                        </label>
                        <select class="search form-control" name="leads_status" id="leads_status">
                            <option value><?php echo e(trans('global.all')); ?></option>
                            <option value="new" <?php if(isset($filters['leads_status']) && $filters['leads_status'] == 'new'): ?> selected <?php endif; ?>>New</option>
                            <option value="duplicate" <?php if(isset($filters['leads_status']) && $filters['leads_status'] == 'duplicate'): ?> selected <?php endif; ?>>Duplicate</option>
                        </select>
                    </div>
                    <?php if(auth()->user()->is_superadmin): ?>
                        <div class="col-md-3 mt-auto mb-2">
                            <div class="form-check">
                                <input class="form-check-input search" type="checkbox" id="no_lead_id" value="1" <?php if(isset($filters['no_lead_id']) && $filters['no_lead_id'] != 'false'): ?> checked <?php endif; ?>>
                                <label for="no_lead_id" class="form-check-label">
                                    <?php echo app('translator')->get('messages.no_lead_id'); ?>
                                </label>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if($lead_view == 'kanban'): ?>
                        <div class="col-md-3">
                            <label></label>
                            <button type="button" class="btn btn-block btn-outline-info" id="filter_leads">
                                <?php echo app('translator')->get('messages.filter_leads'); ?>
                            </button>
                        </div>
                    <?php endif; ?>
                    <?php if(auth()->user()->is_superadmin): ?>
                        <div class="col-md-3">
                            <label></label>
                            <button type="button" class="btn btn-block btn-outline-primary" id="send_bulk_outgoing_webhook">
                                <?php echo app('translator')->get('messages.send_outgoing_webhook'); ?>
                            </button>
                        </div>
                    <?php endif; ?>
                    <div class="col-md-12"><hr></div>
                    <?php if(auth()->user()->is_superadmin): ?>
                        <div class="col-md-3 additional_columns_to_export_div"
                            style="display: none;">
                        </div>
                        <div class="col-md-3 mb-auto mt-auto">
                            <label></label>
                            <button type="button" class="btn btn-block btn-outline-info" id="download_excel">
                                <?php echo app('translator')->get('messages.download_excel'); ?>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH /var/www/html/resources/views/admin/leads/partials/header.blade.php ENDPATH**/ ?>