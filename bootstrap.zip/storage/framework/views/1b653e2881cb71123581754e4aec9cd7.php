<div class="row">
    <div class="col-md-5">
        <div class="form-group">
            <label class="required">
                <?php echo app('translator')->get('messages.key'); ?>
            </label>
            <?php if(isset($webhook_fields) && !empty($webhook_fields)): ?>
                <select name="lead_details[<?php echo e($index); ?>][key]" class="form-control select-tags" required>
                    <option value=""><?php echo app('translator')->get('messages.please_select'); ?></option>
                    <?php $__currentLoopData = $webhook_fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $webhook_field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($webhook_field); ?>"
                            <?php if(isset($key) && !empty($key) && $key == $webhook_field): ?>
                                selected
                            <?php endif; ?>>
                            <?php echo e($webhook_field); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            <?php else: ?>
                <input type="text" name="lead_details[<?php echo e($index); ?>][key]" value="<?php echo e($key ?? ''); ?>" class="form-control" required <?php if(isset($set_key_readonly) && $set_key_readonly): ?> readonly <?php endif; ?>>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label class="<?php if(isset($set_key_readonly) && $set_key_readonly): ?> <?php else: ?> required <?php endif; ?>">
                <?php echo app('translator')->get('messages.value'); ?>
            </label>
            <input type="text" name="lead_details[<?php echo e($index); ?>][value]" value="<?php echo e($value ?? ''); ?>" class="form-control" 
            
            <?php if(isset($set_key_readonly) && $set_key_readonly): ?> <?php else: ?> required <?php endif; ?>>
        </div>
    </div>
    <div class="col-md-1 mt-auto mb-auto">
        <div class="form-group">
            <button type="button" class="btn btn-danger btn-sm float-right delete_lead_detail_row">
                <i class="fas fa-trash-alt"></i>
            </button>
        </div>
    </div>
</div><?php /**PATH /var/www/html/resources/views/admin/leads/partials/lead_detail.blade.php ENDPATH**/ ?>