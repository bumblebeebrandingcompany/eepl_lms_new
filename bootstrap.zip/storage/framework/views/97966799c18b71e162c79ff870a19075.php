<?php $__env->startSection('content'); ?>
<div class="row mb-2">
    <div class="col-sm-6">
        <h2> Walkin <?php echo e(trans('global.list')); ?></h2>
    </div>
</div>

<div class="card card-primary card-outline">

    <div class="card-header">
        
        <a class="btn btn-success float-right" href="<?php echo e(route('admin.aztec.create')); ?>">
            <?php echo e(trans('global.add')); ?> Walkin
        </a>
        
    </div>

    <div class="card-body">
        <div class="table-responsive">

            <table class="table table-bordered table-striped table-hover ajaxTable datatable datatable-Client">

                <thead>
                    <tr>
                        <th width="10"></th>
                        <th>Ref num </th>

                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>City</th>

                        <th>Sell.do.id</th>
                        <th>Status</th>
                        <th>
                            Sell.do.date
                        </th>
                        <th>
                            Sell.do.time
                        </th>
                        <th>Referred By</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $enquires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td width="10"></td>
                        <?php $__currentLoopData = $enquiry->leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td> <?php echo e($lead->ref_num); ?></td>


                        <td> <?php echo e($enquiry->name); ?></td>
                        <td> <?php echo e($enquiry->email); ?></td>
                        <td> <?php echo e($enquiry->phone); ?></td>
                        <td> <?php echo e($enquiry->city); ?></td>
                        <td> <?php echo e($lead->sell_do_lead_id); ?></td>
                        <td>
                            <?php if($lead->sell_do_is_exist): ?>
                            <b class="text-danger">Duplicate</b>
                            <?php else: ?>
                            <b class="text-success">New</b>
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php if(!empty($lead->sell_do_lead_created_at)): ?>
                            <?php echo e(Carbon\Carbon::parse($lead->sell_do_lead_created_at)->format('d/m/Y')); ?>

                            <?php endif; ?>
                        </td>

                        <td>
                            <?php if(!empty($lead->sell_do_lead_created_at)): ?>
                            <?php echo e(Carbon\Carbon::parse($lead->sell_do_lead_created_at)->format('h:i A')); ?>

                            <?php endif; ?>
                        </td>
                        <td> <?php echo e($enquiry->referred_by); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td>
                            <div class="d-flex justify-content-between flex-nowrap">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <!-- Button to trigger the edit modal -->
                                        <a href="<?php echo e(route('admin.aztec.show', $enquiry->id)); ?>"
                                            class="btn btn-primary btn-sm">
                                            View
                                        </a>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <!-- Button to trigger the edit modal -->
                                        <a href="<?php echo e(route('admin.aztec.edit', $enquiry->id)); ?>"
                                            class="btn btn-info btn-sm">
                                            Edit
                                        </a>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <!-- Button to trigger the delete modal -->
                                        <button type="button" class="btn btn-danger btn-sm" data-toggle="modal"
                                            data-target="#deleteModal<?php echo e($enquiry->id); ?>">
                                            Delete
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </td>



                        <!-- Delete Modal -->
                        <div class="modal fade" id="deleteModal<?php echo e($enquiry->id); ?>" tabindex="-1" role="dialog"
                            aria-labelledby="deleteModalLabel<?php echo e($enquiry->id); ?>" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="deleteModalLabel<?php echo e($enquiry->id); ?>">Delete
                                            Walkin</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body d-flex">
                                        <div>
                                            <p>Are you sure you want to delete this enquiry?</p>

                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-dismiss="modal">Cancel</button>
                                        <form action="<?php echo e(route('admin.aztec.destroy', $enquiry->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger">Delete</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
        // Existing JavaScript code for DataTable initialization

        // Additional customization for DataTable
        let table = $('.datatable-Client').DataTable();
        table.on('draw.dt', function () {
            // Add any additional customization after the table is drawn
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/enquires/index.blade.php ENDPATH**/ ?>