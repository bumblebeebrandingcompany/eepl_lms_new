<?php $__env->startSection('content'); ?>
<div class="row mb-2">
   <div class="col-sm-6">
        <h2>
            <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.user.title')); ?>

        </h2>
   </div>
</div>
<div class="row">
    <div class="col-md-4">
        <div class="card card-primary card-outline">
            <div class="card-header">
                <a class="btn btn-default float-right" href="<?php echo e(route('admin.users.index')); ?>">
                    <i class="fas fa-chevron-left"></i>
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <table class="table table-bordered table-striped">
                        <tbody>
                            <tr>
                                <th>
                                    <?php echo e(trans('messages.ref_num')); ?>

                                </th>
                                <td>
                                    <?php echo e($user->ref_num); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>
                                    <?php echo e(trans('cruds.user.fields.name')); ?>

                                </th>
                                <td>
                                    <?php echo e($user->name); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>
                                    <?php echo e(trans('messages.representative_name')); ?>

                                </th>
                                <td>
                                    <?php echo e($user->representative_name); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>
                                    <?php echo e(trans('cruds.user.fields.email')); ?>

                                </th>
                                <td>
                                    <?php echo e($user->email); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>
                                    <?php echo e(trans('cruds.user.fields.email_verified_at')); ?>

                                </th>
                                <td>
                                    <?php echo e($user->email_verified_at); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>
                                    <?php echo e(trans('cruds.user.fields.user_type')); ?>

                                </th>
                                <td>
                                    <?php echo e(App\Models\User::USER_TYPE_RADIO[$user->user_type] ?? ''); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>
                                    <?php echo e(trans('cruds.user.fields.address')); ?>

                                </th>
                                <td>
                                    <?php echo e($user->address); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>
                                    <?php echo e(trans('cruds.user.fields.contact_number_1')); ?>

                                </th>
                                <td>
                                    <?php echo e($user->contact_number_1); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>
                                    <?php echo e(trans('cruds.user.fields.contact_number_2')); ?>

                                </th>
                                <td>
                                    <?php echo e($user->contact_number_2); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>
                                    <?php echo e(trans('cruds.user.fields.website')); ?>

                                </th>
                                <td>
                                    <?php echo e($user->website); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>
                                    <?php echo e(trans('cruds.user.fields.client')); ?>

                                </th>
                                <td>
                                    <?php echo e($user->client->name ?? ''); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>
                                    <?php echo e(trans('cruds.user.fields.agency')); ?>

                                </th>
                                <td>
                                    <?php echo e($user->agency->name ?? ''); ?>

                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card card-primary card-outline">
            <div class="card-header">
                <?php echo e(trans('global.relatedData')); ?>

            </div>
            <ul class="nav nav-tabs" role="tablist" id="relationship-tabs">
                <li class="nav-item">
                    <a class="nav-link active show" href="#created_by_projects" role="tab" data-toggle="tab">
                        <?php echo e(trans('cruds.project.title')); ?>

                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#client_projects" role="tab" data-toggle="tab">
                        <?php echo e(trans('cruds.project.title')); ?>

                    </a>
                </li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane active show" role="tabpanel" id="created_by_projects">
                    <?php if ($__env->exists('admin.users.relationships.createdByProjects', ['projects' => $user->createdByProjects])) echo $__env->make('admin.users.relationships.createdByProjects', ['projects' => $user->createdByProjects], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="tab-pane" role="tabpanel" id="client_projects">
                    <?php if ($__env->exists('admin.users.relationships.clientProjects', ['projects' => $user->clientProjects])) echo $__env->make('admin.users.relationships.clientProjects', ['projects' => $user->clientProjects], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/users/show.blade.php ENDPATH**/ ?>