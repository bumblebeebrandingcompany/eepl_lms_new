<div class="row">
    <div class="col-md-12">
        <?php if(!empty($event)): ?>
            <input type="hidden" name="lead_event_id" class="form-control" value="<?php echo e($event->id); ?>">
        <?php endif; ?>
        <div class="card card-primary card-outline">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="required" for="project_id"><?php echo e(trans('messages.project')); ?></label>
                            <select name="project_id" id="project_id" class="form-control <?php echo e($errors->has('project_id') ? 'is-invalid' : ''); ?>" readonly disabled>
                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>"
                                        <?php if($id == 1): ?> selected <?php endif; ?>>
                                        <?php echo e($project); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('project_id')): ?>
                                <span class="text-danger">Project is required.</span>
                            <?php endif; ?>
                            <span class="help-block text-muted"><?php echo e(trans('messages.choose_project')); ?></span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="search_phone" class="required">
                                <?php echo app('translator')->get('messages.phone'); ?>
                            </label>
                            <div class="input-group">
                                <input type="text" name="search_phone" id="search_phone" value="<?php echo e(old('search_phone') ? old('search_phone') : ($phone ?? '')); ?>" class="form-control input_number">
                                <div class="input-group-append search_lead cursor-pointer">
                                    <span class="input-group-text">
                                        Search
                                    </span>
                                </div>
                            </div>
                            <span class="help-block text-muted">
                                <?php echo e(trans('messages.search_lead_by_phone')); ?> <br>
                                Enter phone number including country code without + sign.
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row info_section sell_do_and_lead_info">
    <?php if ($__env->exists('admin.bookings.partials.sell_do_and_lead_info')) echo $__env->make('admin.bookings.partials.sell_do_and_lead_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="row info_section">
    <div class="col-md-12">
        <div id="basic_details_of_co_applicant_accordion">
            <div class="card card-primary card-outline">
                <div class="card-header">
                    <h4 class="card-title w-100">
                        <a class="d-block w-100 collapsed" data-toggle="collapse" href="#basic_details_of_co_applicant_accordion_collapse" aria-expanded="false">
                            <i class="fas fa-plus"></i>
                            Add Co-Applicant
                        </a>
                    </h4>
                </div>
                <div id="basic_details_of_co_applicant_accordion_collapse" class="collapse" data-parent="#basic_details_of_co_applicant_accordion">
                    <div class="card-body">
                        <div class="row mb-2">
                            <div class="col-md-12">
                                <h5>
                                    <?php echo app('translator')->get('messages.basic_details_of_co_applicant'); ?>
                                </h5>
                            </div>
                        </div>
                        <div class="row basic_common_details_of_co_applicant">
                            <?php if ($__env->exists('admin.bookings.partials.basic_common_details_of_co_applicant')) echo $__env->make('admin.bookings.partials.basic_common_details_of_co_applicant', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row info_section">
    <div class="col-md-12">
        <div class="card card-primary card-outline">
            <div class="card-header">
                <h3 class="card-title">
                    Plot Details
                </h3>
            </div>
            <?php
                $Plot_Details = $event->webhook_data['Plot_Details'] ?? [];
            ?>
            <div class="card-body">
                <div class="form-group">
                    <label for="Plot_no">
                        Plot No
                    </label>
                    <input type="text" name="Plot_Details[Plot_no]" id="Plot_no" class="form-control"
                        value="<?php echo $Plot_Details['Plot_no'] ?? ''; ?>">
                </div>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <label for="Extent_in_SQFT">
                        Extent in SQFT.
                    </label>
                    <input type="text" name="Plot_Details[Extent_in_SQFT]" id="Extent_in_SQFT" class="form-control"
                        value="<?php echo $Plot_Details['Extent_in_SQFT'] ?? ''; ?>">
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row info_section">
    <div class="col-md-12">
        <div class="card card-primary card-outline">
            <div class="card-header">
                <h3 class="card-title">
                     Application Date
                </h3>
            </div>
            <?php
                $Booking_Application_Date = $event->webhook_data['Booking_Application_Date'] ?? [];
            ?>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="Application_date">
                                Application date
                            </label>
                            <input type="text" name="Booking_Application_Date[Application_date]" id="Application_date" class="form-control application_date" readonly value="<?php echo e($Booking_Application_Date['Application_date'] ?? ''); ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="Application_time">
                                Application time
                            </label>
                            <input type="text" name="Booking_Application_Date[Application_time]" id="Application_time" class="form-control application_time" readonly value="<?php echo e($Booking_Application_Date['Application_time'] ?? ''); ?>">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row info_section">
    <div class="col-md-12">
        <div class="card card-primary card-outline">
            <div class="card-header">
                <h3 class="card-title">
                    Type of Buyer
                </h3>
            </div>
            <div class="card-body">
            <?php
                $Loan = $event->webhook_data['Type_of_Buyer'] ?? [];
            ?>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="type_of_buyer" class="required">
                                Type of Buyer
                            </label>
                            <select name="Type_of_Buyer[type_of_buyer]" id="type_of_buyer" class="form-control" required>
                                <option value=""><?php echo app('translator')->get('messages.please_select'); ?></option>
                                <option value="End User" selected >End User</option>
                                <option value="Invester"  selected >Invester</option>
                            </select>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<div class="row info_section">
    <div class="col-md-12">
        <div class="card card-primary card-outline">
            <div class="card-header">
                <h3 class="card-title">
                    Loan
                </h3>
            </div>
            <div class="card-body">
            <?php
                $Loan = $event->webhook_data['Loan'] ?? [];
            ?>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="interested_in_loan" class="required">
                                Interested in loan
                            </label>
                            <select name="Loan[interested_in_loan]" id="interested_in_loan" class="form-control" required>
                                <option value=""><?php echo app('translator')->get('messages.please_select'); ?></option>
                                <option value="Yes" <?php if(!empty($Loan['interested_in_loan']) && $Loan['interested_in_loan'] == 'Yes'): ?> selected <?php endif; ?>>Yes</option>
                                <option value="No" <?php if(!empty($Loan['interested_in_loan']) && $Loan['interested_in_loan'] == 'No'): ?> selected <?php endif; ?>>No</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4 loan_div">
                        <div class="form-group">
                            <label for="loan_amount">
                                Loan Amount
                            </label>
                            <input type="number" name="Loan[loan_amount]" id="loan_amount" class="form-control" value="<?php echo e($Loan['loan_amount'] ?? ''); ?>">
                        </div>
                    </div>
                    <div class="col-md-4 loan_div">
                        <div class="form-group">
                            <label for="loan_from_which_bank">
                                Loan from which bank
                            </label>
                            <input type="text" name="Loan[loan_from_which_bank]" id="loan_from_which_bank" class="form-control" value="<?php echo e($Loan['loan_from_which_bank'] ?? ''); ?>">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row info_section">
    <div class="col-md-12">
        <div class="card card-primary card-outline">
            <div class="card-header">
                <h3 class="card-title">
                    Advance Amount
                </h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <?php
                        $Advance_Amount = $event->webhook_data['Advance_Amount'] ?? [];
                    ?>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="Cheque_No">
                                Cheque No.
                            </label>
                            <input type="text" name="Advance_Amount[Cheque_No]" id="Cheque_No" class="form-control" value="<?php echo e($Advance_Amount['Cheque_No'] ?? ''); ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="adv_amount_date">
                                Date
                            </label>
                            <input type="text" name="Advance_Amount[date]" id="adv_amount_date" class="form-control adv_amount_date" value="<?php echo e($Advance_Amount['date'] ?? ''); ?>" readonly>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="adv_amount_bank">
                                Bank/Branch
                            </label>
                            <input type="text" name="Advance_Amount[bank]" id="adv_amount_bank" class="form-control" value="<?php echo e($Advance_Amount['bank'] ?? ''); ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="Advance_Amount_amount">
                                Amount
                            </label>
                            <input type="number" name="Advance_Amount[amount]" id="Advance_Amount_amount" class="form-control" value="<?php echo e($Advance_Amount['amount'] ?? ''); ?>">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row info_section">
    <div class="col-md-12">
        <div class="card card-primary card-outline">
            <div class="card-header">
                <h3 class="card-title">
                    Financing Plan
                </h3>
            </div>
            <div class="card-body">
                <?php
                    $Financing_Plan = $event->webhook_data['Financing_Plan'] ?? [];
                ?>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="Financing_Plan_interested_in_loan" class="required">
                                Interested in loan
                            </label>
                            <select name="Financing_Plan[interested_in_loan]" id="Financing_Plan_interested_in_loan" class="form-control" required>
                                <option value=""><?php echo app('translator')->get('messages.please_select'); ?></option>
                                <option value="Yes" <?php if(!empty($Financing_Plan['interested_in_loan']) && $Financing_Plan['interested_in_loan'] == 'Yes'): ?> selected <?php endif; ?>>Yes</option>
                                <option value="No" <?php if(!empty($Financing_Plan['interested_in_loan']) && $Financing_Plan['interested_in_loan'] == 'No'): ?> selected <?php endif; ?>>No</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4 Financing_Plan_div">
                        <div class="form-group">
                            <label for="Financing_Plan_Preferred_Bank">
                                Preferred Bank
                            </label>
                            <input type="text" name="Financing_Plan[preferred_bank]" id="Financing_Plan_Preferred_Bank" class="form-control" value="<?php echo e($Financing_Plan['preferred_bank'] ?? ''); ?>">
                        </div>
                    </div>
                    <div class="col-md-4 Financing_Plan_div">
                        <div class="form-group">
                            <label for="Financing_Plan_Own_Fund">
                                Own Fund
                            </label>
                            <input type="text" name="Financing_Plan[own_fund]" id="Financing_Plan_Own_Fund" class="form-control"
                            value="<?php echo e($Financing_Plan['own_fund'] ?? ''); ?>">
                        </div>
                    </div>
                    <div class="col-md-6 Financing_Plan_div">
                        <div class="form-group">
                            <label for="Financing_Plan_amount_of_loan">
                                Amount of Loan
                            </label>
                            <input type="number" name="Financing_Plan[amount_of_loan]" id="Financing_Plan_amount_of_loan" class="form-control" value="<?php echo e($Financing_Plan['amount_of_loan'] ?? ''); ?>">
                        </div>
                    </div>
                    <div class="col-md-6 Financing_Plan_div">
                        <div class="form-group">
                            <label for="Financing_Plan_Total">
                                Total
                            </label>
                            <input type="number" name="Financing_Plan[total]" id="Financing_Plan_Total" class="form-control" value="<?php echo e($Financing_Plan['total'] ?? ''); ?>">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- <div class="row info_section">
   <div class="col-md-12">
        <div class="card card-primary card-outline">
            <div class="card-header">
                <h3 class="card-title">
                    Sales Person Details
                </h3>
            </div>
            <div class="card-body">
                <?php
                    $Sales_Person_Details = $event->webhook_data['Sales_Person_Details'] ?? [];
                ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="Sales_Person_Details_Sell_do_ID">
                                Sell.do ID
                            </label>
                            <input type="text" name="Sales_Person_Details[Sell_do_ID]" id="Sales_Person_Details_Sell_do_ID" class="form-control" value="<?php echo e($Sales_Person_Details['Sell_do_ID'] ?? ''); ?>" disabled>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="Sales_Person_Details_Sell_do_name">
                                Name
                            </label>
                            <input type="text" name="Sales_Person_Details[name]" id="Sales_Person_Details_Sell_do_name" class="form-control" value="<?php echo e($Sales_Person_Details['name'] ?? ''); ?>" disabled>
                        </div>
                    </div>
                </div>
            </div>
        </div>
   </div>
</div> -->
<div class="row info_section">
   <div class="col-md-12">
        <div class="card card-primary card-outline">
            <div class="card-body">
                <?php
                    $other = $event->webhook_data['other'] ?? [];
                ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="is_planning_to_construct_home" class="required">
                                Planning to Construct Home ?
                            </label>
                            <select name="other[is_planning_to_construct_home]" id="is_planning_to_construct_home" class="form-control" required>
                                <option value=""><?php echo app('translator')->get('messages.please_select'); ?></option>
                                <option value="Yes" <?php if(!empty($other['is_planning_to_construct_home']) && $other['is_planning_to_construct_home'] == 'Yes'): ?> selected <?php endif; ?>>Yes</option>
                                <option value="No" <?php if(!empty($other['is_planning_to_construct_home']) && $other['is_planning_to_construct_home'] == 'No'): ?> selected <?php endif; ?>>No</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="Planning_to_Construct_Home">
                                If Yes, Please mention when ?
                            </label>
                            <select name="other[planning_to_construct_home]" id="Planning_to_Construct_Home" class="form-control">
                                <option value=""><?php echo app('translator')->get('messages.please_select'); ?></option>
                                <option value="Immediately" <?php if(!empty($other['planning_to_construct_home']) && $other['planning_to_construct_home'] == 'Immediately'): ?> selected <?php endif; ?>>Immediately</option>
                                <option value="Within 6-12 months" <?php if(!empty($other['planning_to_construct_home']) && $other['planning_to_construct_home'] == 'Within 6-12 months'): ?> selected <?php endif; ?>>Within 6-12 months</option>
                                <option value="After 1 year" <?php if(!empty($other['planning_to_construct_home']) && $other['planning_to_construct_home'] == 'After 1 year'): ?> selected <?php endif; ?>>After 1 year</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
   </div>
</div>
<?php /**PATH /var/www/html/resources/views/admin/bookings/partials/form.blade.php ENDPATH**/ ?>