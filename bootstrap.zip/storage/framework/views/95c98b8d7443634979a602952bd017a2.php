<div class="m-3">
    <div class="card card-primary card-outline">
        <?php if(auth()->user()->is_superadmin): ?>
            <div class="card-header">
                <a class="btn btn-success float-right" href="<?php echo e(route('admin.campaigns.create')); ?>">
                    <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.campaign.title_singular')); ?>

                </a>
            </div>
        <?php endif; ?>
        <div class="card-body">
            <div class="table-responsive">
                <table class=" table table-bordered table-striped table-hover datatable datatable-agencyCampaigns">
                    <thead>
                        <tr>
                            <th width="10">

                            </th>
                            <th>
                                <?php echo e(trans('cruds.campaign.fields.campaign_name')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.campaign.fields.start_date')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.campaign.fields.end_date')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.campaign.fields.project')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.campaign.fields.agency')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.campaign.fields.created_at')); ?>

                            </th>
                            <th>
                                &nbsp;
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr data-entry-id="<?php echo e($campaign->id); ?>">
                                <td>

                                </td>
                                <td>
                                    <?php echo e($campaign->campaign_name ?? ''); ?>

                                </td>
                                <td>
                                    <?php echo e($campaign->start_date ?? ''); ?>

                                </td>
                                <td>
                                    <?php echo e($campaign->end_date ?? ''); ?>

                                </td>
                                <td>
                                    <?php echo e($campaign->project->name ?? ''); ?>

                                </td>
                                <td>
                                    <?php echo e($campaign->agency->name ?? ''); ?>

                                </td>
                                <td>
                                    <?php echo e($campaign->created_at ?? ''); ?>

                                </td>
                                <td>
                                    <?php if(auth()->user()->is_superadmin): ?>
                                        <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.campaigns.show', $campaign->id)); ?>">
                                            <?php echo e(trans('global.view')); ?>

                                        </a>
                                    <?php endif; ?>

                                    <?php if(auth()->user()->is_superadmin): ?>
                                        <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.campaigns.edit', $campaign->id)); ?>">
                                            <?php echo e(trans('global.edit')); ?>

                                        </a>
                                    <?php endif; ?>

                                    <?php if(auth()->user()->is_superadmin): ?>
                                        <form action="<?php echo e(route('admin.campaigns.destroy', $campaign->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                            <input type="hidden" name="_method" value="DELETE">
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <input type="submit" class="btn btn-xs btn-danger" value="<?php echo e(trans('global.delete')); ?>">
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
  <?php if(auth()->user()->is_superadmin): ?>
  let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "<?php echo e(route('admin.campaigns.massDestroy')); ?>",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

        return
      }

      if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
<?php endif; ?>

  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  let table = $('.datatable-agencyCampaigns:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
<?php $__env->stopSection(); ?><?php /**PATH /var/www/html/resources/views/admin/agencies/relationships/agencyCampaigns.blade.php ENDPATH**/ ?>