<div class="col-md-12">
    <div class="card card-primary card-outline">
        <div class="card-header">
            <h3 class="card-title">
                Sell.do details
            </h3>
        </div>
        <div class="card-body">
            <div class="row">
                <?php if ($__env->exists('admin.bookings.partials.sell_do_detail')) echo $__env->make('admin.bookings.partials.sell_do_detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</div>
<div class="col-md-12">
    <div class="card card-primary card-outline">
        <div class="card-header">
            <h3 class="card-title">
                <?php echo app('translator')->get('messages.basic_details_of_applicant'); ?>
            </h3>
        </div>
        <div class="card-body">
            <div class="row basic_common_details_of_applicant">
                <?php if ($__env->exists('admin.bookings.partials.basic_details_of_applicant')) echo $__env->make('admin.bookings.partials.basic_details_of_applicant', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /var/www/html/resources/views/admin/bookings/partials/sell_do_and_lead_info.blade.php ENDPATH**/ ?>