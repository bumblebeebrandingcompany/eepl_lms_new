<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h1>Show MerlomLead</h1>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="walkinDetailsTable">
                            <tbody>
                                <tr>
                                    <th>Ref Num</th>
                                    <td><?php echo e($merlomLead->ref_num); ?></td>
                                </tr>
                                <tr>
                                    <th>Name</th>
                                    <td><?php echo e($merlomLead->name); ?></td>
                                </tr>
                                <tr>
                                    <th>Email</th>
                                    <td><?php echo e($merlomLead->email); ?></td>
                                </tr>
                                <tr>
                                    <th>Phone</th>
                                    <td><?php echo e($merlomLead->phone); ?></td>
                                </tr>
                                <tr>
                                    <th>Project</th>
                                    <td><?php echo e($merlomLead->project->name ?? ''); ?></td>
                                </tr>
                                <tr>
                                    <th>Source</th>
                                    <td><?php echo e($merlomLead->source); ?></td>
                                </tr>
                                <tr>
                                    <th>Sub Source</th>
                                    <td><?php echo e($merlomLead->sub_source); ?></td>
                                </tr>
                                <tr>
                                    <th>Sell.do.id</th>
                                    <td><?php echo e($merlomLead->sell_do_id); ?></td>
                                </tr>
                                <tr>
                                    <th>Status</th>
                                    <td><?php echo $merlomLead->status == 0 ? '<b class="text-danger">Duplicate</b>' : '<b class="text-success">New</b>'; ?></td>
                                </tr>


                                <!-- Add other fields as needed -->
                            </tbody>
                        </table>
                    </div>

                    <a href="<?php echo e(route('admin.merlom-leads.index')); ?>" class="btn btn-primary">Back to List</a>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function() {
                $('#walkinDetailsTable').DataTable({
                    "paging": false,
                    "searching": false,
                    "info": false,
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/merlomleads/show.blade.php ENDPATH**/ ?>