<div class="m-3">
    <div class="card">
        <?php if(auth()->user()->checkPermission('lead_create')): ?>
            <div class="card-header">
                <a class="btn btn-success float-right" href="<?php echo e(route('admin.leads.create')); ?>">
                    <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.lead.title_singular')); ?>

                </a>
            </div>
        <?php endif; ?>
        <div class="card-body">
            <div class="table-responsive">
                <table class=" table table-bordered table-striped table-hover datatable datatable-campaignLeads">
                    <thead>
                        <tr>
                            <th width="10">

                            </th>
                            <th>
                                <?php echo e(trans('cruds.lead.fields.id')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('messages.email')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('messages.phone')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.lead.fields.project')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.lead.fields.campaign')); ?>

                            </th>
                            <th>
                                &nbsp;
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr data-entry-id="<?php echo e($lead->id); ?>">
                                <td>

                                </td>
                                <td>
                                    <?php echo e($lead->id ?? ''); ?>

                                </td>
                                <td>
                                    <?php echo e($lead->email ?? ''); ?>

                                </td>
                                <td>
                                    <?php echo e($lead->phone ?? ''); ?>

                                </td>
                                <td>
                                    <?php echo e($lead->project->name ?? ''); ?>

                                </td>
                                <td>
                                    <?php echo e($lead->campaign->campaign_name ?? ''); ?>

                                </td>
                                <td>
                                    <?php if(auth()->user()->checkPermission('lead_view')): ?>
                                        <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.leads.show', $lead->id)); ?>">
                                            <?php echo e(trans('global.view')); ?>

                                        </a>
                                    <?php endif; ?>
                                    <?php if(auth()->user()->checkPermission('lead_edit')): ?>
                                        <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.leads.edit', $lead->id)); ?>">
                                            <?php echo e(trans('global.edit')); ?>

                                        </a>
                                    <?php endif; ?>
                                    <?php if(auth()->user()->checkPermission('lead_delete')): ?>
                                        <form action="<?php echo e(route('admin.leads.destroy', $lead->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                            <input type="hidden" name="_method" value="DELETE">
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <input type="submit" class="btn btn-xs btn-danger" value="<?php echo e(trans('global.delete')); ?>">
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
  <?php if(auth()->user()->checkPermission('lead_delete')): ?>
  let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "<?php echo e(route('admin.leads.massDestroy')); ?>",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

        return
      }

      if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
<?php endif; ?>

  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  let table = $('.datatable-campaignLeads:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
<?php $__env->stopSection(); ?><?php /**PATH /var/www/html/resources/views/admin/campaigns/relationships/campaignLeads.blade.php ENDPATH**/ ?>