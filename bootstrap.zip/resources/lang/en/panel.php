<?php

return [
    'site_title' => 'LMS',

];
