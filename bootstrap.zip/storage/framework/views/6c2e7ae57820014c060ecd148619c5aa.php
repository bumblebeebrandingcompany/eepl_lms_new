<?php $__env->startSection('content'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h2>
               Walkin
            </h2>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card card-primary card-outline">
                <div class="card-header">
                    <a class="btn btn-default float-right" href="<?php echo e(route('admin.aztec.index')); ?>">
                        <i class="fas fa-chevron-left"></i>
                        <?php echo e(trans('global.back_to_list')); ?>

                    </a>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <table class="table table-bordered table-striped">
                            <tbody>
                                <?php $__currentLoopData = $enquiry->leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                   
                                        <th>
                                          Ref Num
                                        </th>

                                        <td> <?php echo e($lead->ref_num); ?></td>
                                    </tr>
                                    <tr>
                                    <th>
                                        <?php echo e(trans('cruds.client.fields.name')); ?>

                                    </th>
                                    <td>
                                        <?php echo e($enquiry->name); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        Email
                                    </th>
                                    <td>
                                        <?php echo e($enquiry->email); ?>

                                    </td>
                                </tr>
                                
                                <tr>
                                    <th>
                                        Phone
                                    </th>
                                    <td class="word-break">
                                        <?php echo e($enquiry->phone); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        City
                                    </th>
                                    <td>
                                        <?php echo e($enquiry->city); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        Sell.do.id
                                    </th>
                                    <td> <?php echo e($lead->sell_do_lead_id); ?></td>
                               
                                </tr>
                                <tr>
                                    <th>
                                        Status
                                    </th>
                                    <td>
                                        <?php if($lead->sell_do_is_exist): ?>
                                            <b class="text-danger">Duplicate</b>
                                        <?php else: ?>
                                            <b class="text-success">New</b>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        Sell.do.date
                                    </th>
                                    <td>
                                        <?php if(!empty($lead->sell_do_lead_created_at)): ?>
                                            <?php echo e(Carbon\Carbon::parse($lead->sell_do_lead_created_at)->format('d/m/Y')); ?>

                                        <?php endif; ?>
                                    </td>
                                  
                               
                                </tr>
                                <tr>
                                    <th>
                                        Sell.do.time
                                    </th>
                                    <td>
                                        <?php if(!empty($lead->sell_do_lead_created_at)): ?>
                                            <?php echo e(Carbon\Carbon::parse($lead->sell_do_lead_created_at)->format('h:i A')); ?>

                                        <?php endif; ?>
                                    </td>
                               
                                </tr>
                                <tr>
                                    <th>
                                        Referred By
                                    </th>
                                    <td>
                                        <?php echo e($enquiry->referred_by); ?>

                                    </td>
                                </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/enquires/show.blade.php ENDPATH**/ ?>