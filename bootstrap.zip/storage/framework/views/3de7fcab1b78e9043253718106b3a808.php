<?php $__env->startSection('content'); ?>
    <div class="row mb-2">
        <div class="col-sm-12 d-flex align-items-center justify-content-between">
            <h2>
               Booking
            </h2>
            <a class="btn btn-default float-right" href="<?php echo e(route('admin.bookings.index')); ?>" id="go_back_to_list_btn">
                <i class="fas fa-chevron-left"></i>
                <?php echo e(trans('global.back_to_list')); ?>

            </a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <?php if ($__env->exists('admin.bookings.partials.lead_details', ['lead' => $event->lead, 'project' => $event->project])) echo $__env->make('admin.bookings.partials.lead_details', ['lead' => $event->lead, 'project' => $event->project], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-md-6">
            <div class="card card-primary card-outline">
                <div class="card-body">
                    <?php if ($__env->exists('admin.leads.partials.event_details.expression_of_interest', ['event' => $event, 'enable_header' => false])) echo $__env->make('admin.leads.partials.event_details.expression_of_interest', ['event' => $event, 'enable_header' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/bookings/show.blade.php ENDPATH**/ ?>