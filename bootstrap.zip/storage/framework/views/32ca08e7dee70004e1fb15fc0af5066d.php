<?php if ($__env->exists('admin.eoi.partials.common_details_of_applicant')) echo $__env->make('admin.eoi.partials.common_details_of_applicant', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(!empty($lead)): ?>
    <input type="hidden" name="lead_id" class="form-control" id="lead_id" value="<?php echo e($lead->id); ?>">
<?php endif; ?>
<div class="col-md-6">
    <div class="form-group">
        <label for="lead_details_sex" class="required">
            <?php echo app('translator')->get('messages.gender'); ?>
        </label>
        <select name="lead_details[gender]" id="lead_details_sex" class="form-control" required>
            <option value=""><?php echo app('translator')->get('messages.please_select'); ?></option>
            <option value="Male" <?php if(!empty($lead) && !empty($lead->lead_info['gender']) && $lead->lead_info['gender'] == 'Male'): ?> selected <?php endif; ?>>Male</option>
            <option value="Female" <?php if(!empty($lead) && !empty($lead->lead_info['gender']) && $lead->lead_info['gender'] == 'Female'): ?> selected <?php endif; ?>>Female</option>
        </select>
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label for="lead_details_Profession">
            Profession
        </label>
        <input type="text" name="lead_details[profession]" id="lead_details_Profession" value="<?php if(!empty($lead) && !empty($lead->lead_info['profession'])): ?> <?php echo e($lead->lead_info['profession']); ?> <?php endif; ?>" class="form-control">
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label for="lead_details_Designation">
            Designation
        </label>
        <input type="text" name="lead_details[designation]" id="lead_details_Designation" value="<?php if(!empty($lead) && !empty($lead->lead_info['designation'])): ?> <?php echo e($lead->lead_info['designation']); ?> <?php endif; ?>" class="form-control">
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label for="lead_details_company_name">
            <?php echo app('translator')->get('messages.company_name'); ?>
        </label>
        <input type="text" name="lead_details[company_name]" id="lead_details_company_name" value="<?php if(!empty($lead) && !empty($lead->lead_info['company_name'])): ?> <?php echo e($lead->lead_info['company_name']); ?> <?php endif; ?>" class="form-control">
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label for="lead_details_residential_status">
            <?php echo app('translator')->get('messages.residential_status'); ?>
        </label>
        <select name="lead_details[residential_status]" id="lead_details_residential_status" class="form-control">
            <option value=""><?php echo app('translator')->get('messages.please_select'); ?></option>
            <option value="Resident" <?php if(!empty($lead) && !empty($lead->lead_info['residential_status']) && $lead->lead_info['residential_status'] == 'Resident'): ?> selected <?php endif; ?>>Resident</option>
            <option value="NRI" <?php if(!empty($lead) && !empty($lead->lead_info['residential_status']) && $lead->lead_info['residential_status'] == 'NRI'): ?> selected <?php endif; ?>">NRI</option>
        </select>
    </div>
</div>
<div class="col-md-12">
    <div class="form-group">
        <label for="lead_details_Correspondence_Address">
            Correspondence Address
        </label>
        <textarea name="lead_details[correspondence_address]" id="lead_details_Correspondence_Address" class="form-control" cols="2"><?php if(!empty($lead) && !empty($lead->lead_info['correspondence_address'])): ?> <?php echo $lead->lead_info['correspondence_address']; ?> <?php endif; ?></textarea>
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label for="lead_details_pan]">
            <?php echo app('translator')->get('messages.pan'); ?>
        </label>
        <input type="text" name="lead_details[pan]" id="lead_details_pan" value="<?php if(!empty($lead) && !empty($lead->lead_info['pan'])): ?> <?php echo e($lead->lead_info['pan']); ?> <?php endif; ?>" class="form-control">
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label for="lead_details_age">
            Age
        </label>
        <input type="text" name="lead_details[age]" id="lead_details_age" value="<?php if(!empty($lead) && !empty($lead->lead_info['age'])): ?> <?php echo e($lead->lead_info['age']); ?> <?php endif; ?>" class="form-control applicant_age">
    </div>
</div><?php /**PATH /var/www/html/resources/views/admin/eoi/partials/basic_details_of_applicant.blade.php ENDPATH**/ ?>