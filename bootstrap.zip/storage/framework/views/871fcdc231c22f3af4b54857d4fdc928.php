<div class="card border-secondary">
    <div class="card-body">
        <div class="row">
            <div class="col-md-7">
                <div class="form-group">
                    <label>
                        <?php echo e(trans('messages.api_to_send_webhook')); ?> *
                    </label>
                    <input type="url" placeholder="<?php echo e(trans('messages.api_to_send_webhook')); ?>" value="<?php echo e($api['url'] ?? ''); ?>" name="api[<?php echo e($key); ?>][url]" class="form-control">
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label>
                        <?php echo e(trans('messages.secret_key')); ?>

                        <i class="fas fa-info-circle" data-html="true" data-toggle="tooltip" title="<?php echo e(trans('messages.12_char_random_str')); ?>"></i>
                    </label>
                    <input type="text" placeholder="<?php echo e(trans('messages.secret_key')); ?>" value="<?php echo e($api['secret_key'] ?? ''); ?>" name="api[<?php echo e($key); ?>][secret_key]" class="form-control">
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <label>
                        <?php echo e(trans('messages.method')); ?> *
                    </label>
                    <select name="api[<?php echo e($key); ?>][method]" class="form-control">
                        <option value="get"
                            <?php if(
                                isset($api['method']) && 
                                !empty($api['method']) &&
                                $api['method'] == 'get'
                            ): ?>
                                selected
                            <?php endif; ?>>
                            GET
                        </option>
                        <option value="post"
                            <?php if(
                                isset($api['method']) && 
                                !empty($api['method']) &&
                                $api['method'] == 'post'
                            ): ?>
                                selected
                            <?php endif; ?>>
                            POST
                        </option>
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label>
                        <?php echo e(trans('messages.headers')); ?>

                    </label>
                    <textarea  class="form-control" name="api[<?php echo e($key); ?>][headers]" rows="3"><?php echo e($api['headers'] ?? ''); ?></textarea>
                    <small class="form-text text-muted">
                        <?php echo e(trans('messages.headers_help_text')); ?> <br>
                        Ex: {"header-1" : "header 1 Value", "header-2" : "header 2 Value", "header3" : "header 3 Value"}
                    </small>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label>
                        <?php echo e(trans('messages.request_body')); ?>

                    </label>
                    <textarea  class="form-control" name="api[<?php echo e($key); ?>][request_body]" rows="3"><?php echo e($api['request_body'] ?? ''); ?></textarea>
                    <small class="form-text text-muted">
                        <?php echo e(trans('messages.request_body_help_text')); ?> <br>
                        <?php if(!empty($tags)): ?>
                            <strong>
                                <?php echo e(trans('messages.available_tags')); ?>:
                            </strong>
                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e('{'.$tag.'}'); ?> <?php if(!$loop->last): ?> <?php echo e(','); ?><?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <strong>
                                <?php echo e(trans('messages.send_webhook_request_to_view_tags')); ?>

                            </strong>
                        <?php endif; ?>
                    </small>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH /var/www/html/resources/views/admin/campaigns/partials/api_card.blade.php ENDPATH**/ ?>