@extends('layouts.admin')
@section('content')
    <div class="row mb-2">
        <div class="col-sm-12">
            <h2>
                @lang('messages.configure_webhook_details')
                <small>
                    <strong>Source:</strong>
                    <span class="text-primary">{{ $source->name }}</span>
                    <strong>Project:</strong>
                    <span class="text-primary">{{ optional($source->project)->name }}</span>
                </small>
            </h2>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card card-primary card-outline">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-6">
                            <h3 class="card-title">
                                {{ trans('messages.receive_webhook') }}
                            </h3>
                        </div>
                        <div class="col-md-6">
                            <a class="btn btn-default float-right" href="{{ route('admin.sources.index') }}">
                                <i class="fas fa-chevron-left"></i>
                                {{ trans('global.back_to_list') }}
                            </a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group webhook_div">
                                    <label for="webhook_url">
                                        {{ trans('messages.webhook_url') }}
                                    </label>
                                    <div class="input-group">
                                        <input type="text" id="webhook_url"
                                            value="{{ route('webhook.processor', ['secret' => $source->webhook_secret]) }}"
                                            class="form-control cursor-pointer copy_link" readonly>
                                        <div class="input-group-append cursor-pointer copy_link">
                                            <span class="input-group-text">
                                                <i class="fas fa-copy"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-5">
                            <div class="col-md-12 d-flex justify-content-between mb-2">
                                <h3>
                                    {{ trans('messages.most_recent_lead') }}
                                </h3>
                                <button type="button" class="btn btn-outline-primary btn-xs refresh_latest_lead">
                                    <i class="fas fa-sync"></i>
                                    {{ trans('messages.refresh') }}
                                </button>
                            </div>
                            <div class="col-md-12">
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>{{ trans('messages.key') }}</th>
                                                <th>{{ trans('messages.value') }}</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @if (!empty($lead) && !empty($lead->lead_info))
                                                @php
                                                    $serial_num = 0;
                                                @endphp
                                                @php
                                                    $decodedData = json_decode($lead->essential_fields, true) ?? [];
                                                    $salesData = json_decode($lead->sales_fields, true) ?? [];
                                                    $systemData = json_decode($lead->system_fields, true) ?? [];
                                                    $customData = json_decode($lead->custom_fields, true) ?? [];
                                                @endphp
                                                @foreach ($decodedData as $key => $value)
                                                
                                                    <tr>
                                                        <td>
                                                            {{ $key }}
                                                        </td>
                                                        <td>
                                                            {{ $value }}
                                                        </td>
                                                    </tr>
                                                @endforeach
                                                @foreach ($salesData as $key => $value)
                                                    <tr>
                                                        <td>
                                                            {{ $key }}
                                                        </td>
                                                        <td>
                                                            {{ $value }}
                                                        </td>
                                                    </tr>
                                                @endforeach
                                                @foreach ($systemData as $key => $value)
                                                    <tr>
                                                        <td>
                                                            {{ $key }}
                                                        </td>
                                                        <td>
                                                            {{ $value }}
                                                        </td>
                                                    </tr>
                                                @endforeach
                                                @foreach ($customData as $key => $value)
                                                    <tr>
                                                        <td>
                                                            {{ $key }}
                                                        </td>
                                                        <td>
                                                            {{ $value }}
                                                        </td>
                                                    </tr>
                                                @endforeach
                                                <tr>
                                                    <td>
                                                        @lang('messages.secondary_phone_key')
                                                    </td>
                                                    <td>
                                                        {{ $lead->secondary_phone ?? '' }}
                                                    </td>
                                                </tr>
                                                @php
                                                    $lead_info = $lead->lead_info;
                                                    $existing_keys = array_keys($lead->lead_info);
                                                    if (
                                                        !empty($lead->source) &&
                                                        !empty($lead->source->name_key) &&
                                                        isset($lead_info[$lead->source->name_key]) &&
                                                        !empty($lead_info[$lead->source->name_key])
                                                    ) {
                                                        unset($lead_info[$lead->source->name_key]);
                                                    }
                                                    if (
                                                        !empty($lead->source) &&
                                                        !empty($lead->source->email_key) &&
                                                        isset($lead_info[$lead->source->email_key]) &&
                                                        !empty($lead_info[$lead->source->email_key])
                                                    ) {
                                                        unset($lead_info[$lead->source->email_key]);
                                                    }

                                                    if (
                                                        !empty($lead->source) &&
                                                        !empty($lead->source->phone_key) &&
                                                        isset($lead_info[$lead->source->phone_key]) &&
                                                        !empty($lead_info[$lead->source->phone_key])
                                                    ) {
                                                        unset($lead_info[$lead->source->phone_key]);
                                                    }

                                                    if (
                                                        !empty($lead->source) &&
                                                        !empty($lead->source->additional_email_key) &&
                                                        isset($lead_info[$lead->source->additional_email_key]) &&
                                                        !empty($lead_info[$lead->source->additional_email_key])
                                                    ) {
                                                        unset($lead_info[$lead->source->additional_email_key]);
                                                    }

                                                    if (
                                                        !empty($lead->source) &&
                                                        !empty($lead->source->secondary_phone_key) &&
                                                        isset($lead_info[$lead->source->secondary_phone_key]) &&
                                                        !empty($lead_info[$lead->source->secondary_phone_key])
                                                    ) {
                                                        unset($lead_info[$lead->source->secondary_phone_key]);
                                                    }
                                                @endphp
                                                @foreach ($lead_info as $key => $value)
                                                    @php
                                                        $serial_num = $loop->iteration;
                                                    @endphp
                                                    <tr>
                                                        <td>
                                                            {!! $key !!}
                                                        </td>
                                                        <td>
                                                            {!! $value !!}
                                                        </td>
                                                    </tr>
                                                @endforeach
                                            @else
                                                <tr>
                                                    <td colspan="2" class="text-center">
                                                        <span class="text-center">
                                                            {{ trans('messages.no_data_found') }}
                                                        </span>
                                                    </td>
                                                </tr>
                                            @endif
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            @php
                                $tags = optional($source->project)->webhook_fields ?? [];
                                $email_label = __('messages.email');
                                $phone_label = __('messages.phone');
                                $name_label = __('messages.name');
                                $addi_email_label = __('messages.additional_email');
                                $secondary_phone_label = __('messages.secondary_phone');
                            @endphp

                            <div class="col-md-12">
                                <form action="{{ route('admin.update.email.and.phone.key') }}" method="post"
                                    enctype="multipart/form-data">
                                    @csrf
                                    <input type="hidden" name="source_id" value="{{ $source->id }}" id="source_id">
                                    <div class="row">

                                        @if ($source->project->essential_fields)
                                            @foreach ($source->project->essential_fields as $key => $essentialField)
                                                @if (isset($essentialField['enabled']) && $essentialField['enabled'] === '1')
                                                    <input type="hidden"
                                                        name="essential_fields[{{ $key }}][name_data]"
                                                        value="{{ $essentialField['name_data'] }}" class="form-control"
                                                        readonly>

                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="required">
                                                                @lang('messages.key')
                                                            </label>
                                                            <input type="text"
                                                                name="essential_fields[{{ $key }}][name_value]"
                                                                value="{{ $essentialField['name_value'] }}"
                                                                class="form-control" readonly>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="name_key" class="required">
                                                                {{ trans('messages.name') }}
                                                                {{ trans('messages.key') }}
                                                            </label><br>
                                                            <select class="form-control select2"
                                                                name="essential_fields[{{ $key }}][name_key]"
                                                                id="name_key">
                                                                <option value="">@lang('messages.please_select')</option>
                                                                @foreach ($tags as $key)
                                                                    <option value="{{ $key }}"
                                                                        @if ($key == $source->name_key || soundex($key) == soundex($name_label)) selected @endif>
                                                                        {{ $key }}
                                                                        @if (!empty($existing_keys) && in_array($key, $existing_keys))
                                                                            (@lang('messages.exist_in_recent_lead'))
                                                                        @endif
                                                                    </option>
                                                                @endforeach
                                                            </select>
                                                        </div>
                                                    </div>
                                                @endif
                                            @endforeach
                                        @else
                                            <div class="form-group">
                                                <label class="required">
                                                    @lang('messages.value')
                                                </label>
                                                <input type="text" name="essential_fields[description]" value=""
                                                    class="form-control">
                                                <div class="col-md-1 mt-auto mb-auto">
                                                    <div class="form-group">
                                                        <button type="button"
                                                            class="btn btn-danger btn-sm float-right delete_request_body_row">
                                                            <i class="fas fa-trash-alt"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        @endif
                                        @if ($source->project->sales_fields)
                                        @foreach ($source->project->sales_fields as $key => $salesField)
                                            @if (isset($salesField['enabled']) && $salesField['enabled'] === '1')
                                                <input type="hidden"
                                                    name="sales_fields[{{ $key }}][name_data]"
                                                    value="{{ $salesField['name_data'] }}" class="form-control"
                                                    readonly>

                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="required">
                                                            @lang('messages.key')
                                                        </label>
                                                        <input type="text"
                                                            name="sales_fields[{{ $key }}][name_value]"
                                                            value="{{ $salesField['name_value'] }}"
                                                            class="form-control" readonly>
                                                    </div>
                                                </div>

                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="name_key" class="required">
                                                            {{ trans('messages.name') }}
                                                            {{ trans('messages.key') }}
                                                        </label><br>
                                                        <select class="form-control select2"
                                                            name="sales_fields[{{ $key }}][name_key]"
                                                            id="name_key">
                                                            <option value="">@lang('messages.please_select')</option>
                                                            @foreach ($tags as $key)
                                                                <option value="{{ $key }}"
                                                                    @if ($key == $source->name_key || soundex($key) == soundex($name_label)) selected @endif>
                                                                    {{ $key }}
                                                                    @if (!empty($existing_keys) && in_array($key, $existing_keys))
                                                                        (@lang('messages.exist_in_recent_lead'))
                                                                    @endif
                                                                </option>
                                                            @endforeach
                                                        </select>
                                                    </div>
                                                </div>
                                            @endif
                                        @endforeach
                                    @else
                                        <div class="form-group">
                                            <label class="required">
                                                @lang('messages.value')
                                            </label>
                                            <input type="text" name="sales_fields[description]" value=""
                                                class="form-control">
                                            <div class="col-md-1 mt-auto mb-auto">
                                                <div class="form-group">
                                                    <button type="button"
                                                        class="btn btn-danger btn-sm float-right delete_request_body_row">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    @endif
                                    @if ($source->project->system_fields)
                                    @foreach ($source->project->system_fields as $key => $systemField)
                                        @if (isset($systemField['enabled']) && $systemField['enabled'] === '1')
                                            <input type="hidden"
                                                name="system_fields[{{ $key }}][name_data]"
                                                value="{{ $systemField['name_data'] }}" class="form-control"
                                                readonly>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="required">
                                                        @lang('messages.key')
                                                    </label>
                                                    <input type="text"
                                                        name="system_fields[{{ $key }}][name_value]"
                                                        value="{{ $systemField['name_value'] }}"
                                                        class="form-control" readonly>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="name_key" class="required">
                                                        {{ trans('messages.name') }}
                                                        {{ trans('messages.key') }}
                                                    </label><br>
                                                    <select class="form-control select2"
                                                        name="system_fields[{{ $key }}][name_key]"
                                                        id="name_key">
                                                        <option value="">@lang('messages.please_select')</option>
                                                        @foreach ($tags as $key)
                                                            <option value="{{ $key }}"
                                                                @if ($key == $source->name_key || soundex($key) == soundex($name_label)) selected @endif>
                                                                {{ $key }}
                                                                @if (!empty($existing_keys) && in_array($key, $existing_keys))
                                                                    (@lang('messages.exist_in_recent_lead'))
                                                                @endif
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                        @endif
                                    @endforeach
                                @else
                                    <div class="form-group">
                                        <label class="required">
                                            @lang('messages.value')
                                        </label>
                                        <input type="text" name="system_fields[description]" value=""
                                            class="form-control">
                                        <div class="col-md-1 mt-auto mb-auto">
                                            <div class="form-group">
                                                <button type="button"
                                                    class="btn btn-danger btn-sm float-right delete_request_body_row">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                @endif
                                @if ($source->project->custom_fields)
                                @foreach ($source->project->custom_fields as $key => $customField)
                                    @if (isset($customField['enabled']) && $customField['enabled'] === '1')
                                        <input type="hidden"
                                            name="custom_fields[{{ $key }}][name_data]"
                                            value="{{ $customField['name_data'] }}" class="form-control"
                                            readonly>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="required">
                                                    @lang('messages.key')
                                                </label>
                                                <input type="text"
                                                    name="custom_fields[{{ $key }}][name_value]"
                                                    value="{{ $customField['name_value'] }}"
                                                    class="form-control" readonly>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="name_key" class="required">
                                                    {{ trans('messages.name') }}
                                                    {{ trans('messages.key') }}
                                                </label><br>
                                                <select class="form-control select2"
                                                    name="custom_fields[{{ $key }}][name_key]"
                                                    id="name_key">
                                                    <option value="">@lang('messages.please_select')</option>
                                                    @foreach ($tags as $key)
                                                        <option value="{{ $key }}"
                                                            @if ($key == $source->name_key || soundex($key) == soundex($name_label)) selected @endif>
                                                            {{ $key }}
                                                            @if (!empty($existing_keys) && in_array($key, $existing_keys))
                                                                (@lang('messages.exist_in_recent_lead'))
                                                            @endif
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    @endif
                                @endforeach
                            @else
                                <div class="form-group">
                                    <label class="required">
                                        @lang('messages.value')
                                    </label>
                                    <input type="text" name="custom_fields[description]" value=""
                                        class="form-control">
                                    <div class="col-md-1 mt-auto mb-auto">
                                        <div class="form-group">
                                            <button type="button"
                                                class="btn btn-danger btn-sm float-right delete_request_body_row">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            @endif


                                    </div>
                                    <div class="row mt-3">
                                        <div class="col-md-4">
                                            <button type="submit" class="btn btn-outline-primary">
                                                {{ trans('messages.save') }}
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('scripts')
    <script>
        $(function() {
            $(document).on('click', '.copy_link', function() {
                copyToClipboard($("#webhook_url").val());
            });

            function copyToClipboard(text) {
                const textarea = document.createElement('textarea');
                textarea.value = text;
                document.body.appendChild(textarea);
                textarea.select();
                document.execCommand('copy');
                document.body.removeChild(textarea);

                const span = document.createElement('span');
                span.innerText = 'Link copied to clipboard!';
                $(".webhook_div").append(span);
                setTimeout(() => {
                    span.remove();
                }, 300);
            }

            $(document).on('click', '.refresh_latest_lead', function() {
                location.reload();
            });
        });
    </script>
@endsection
