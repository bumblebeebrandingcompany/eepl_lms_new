<?php if(!empty($document->files_url)): ?>
    <div class="row existing_files_div">
        <div class="col-md-12">
            <h4><?php echo app('translator')->get('messages.existing_files'); ?></h4>
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>
                            <?php echo app('translator')->get('messages.file'); ?>
                        </th>
                        <th>
                            <?php echo app('translator')->get('messages.action'); ?>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $document->files_url; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th>
                                <?php echo e($file['file_name']); ?> <br>
                                <a href="<?php echo e($file['url'] ?? '#!'); ?>" target="_blank"
                                    download="<?php echo e($file['file_name']); ?>" class="btn btn-outline-primary btn-sm m-2">
                                    <i class="fas fa-download mr-1"></i>
                                    <?php echo e($file['file_name']); ?>

                                </a>
                            </th>
                            <td>
                                <button type="button" data-href="<?php echo e(route('admin.documents.remove.file', ['id' => $document->id])); ?>" class="btn btn-outline-danger btn-sm remove-file" data-file="<?php echo e($file['org_file_name']); ?>">
                                    <i class="fas fa-trash mr-1"></i>
                                    <?php echo app('translator')->get('messages.remove'); ?>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>
<div class="row">
    <div class="col-md-12">
        <h4><?php echo app('translator')->get('messages.upload_files'); ?></h4>
    </div>
    <?php for($i = 0; $i<10; $i++): ?>
        <div class="col-md-6 mb-3">
            <div class="form-group">
                <label for="file_<?php echo e($i); ?>">
                    <?php echo app('translator')->get('messages.choose_file'); ?>
                </label>
                <input type="file" name="files[<?php echo e($i); ?>]" class="form-control-file" id="file_<?php echo e($i); ?>">
            </div>
        </div>
    <?php endfor; ?>
</div><?php /**PATH /var/www/html/resources/views/admin/documents/partials/files.blade.php ENDPATH**/ ?>