<div class="col-md-6">
    <div class="form-group">
        <label for="name" class="required">
            <?php echo app('translator')->get('messages.name'); ?>
        </label>
        <input type="text" name="name" id="name" value="<?php if(!empty($lead) && !empty($lead->name)): ?> <?php echo e($lead->name); ?> <?php endif; ?>" class="form-control" readonly>
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label for="email" class="required">
            <?php echo app('translator')->get('messages.email'); ?>
        </label>
        <input type="email" name="email" id="email" value="<?php if(!empty($lead) && !empty($lead->email)): ?> <?php echo e($lead->email); ?> <?php endif; ?>" class="form-control" readonly>
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label for="additional_email_key">
            <?php echo app('translator')->get('messages.additional_email_key'); ?>
        </label>
        <input type="text" name="additional_email" id="additional_email_key" value="<?php if(!empty($lead) && !empty($lead->additional_email)): ?> <?php echo e($lead->additional_email); ?> <?php endif; ?>" class="form-control" <?php if(!empty($lead) && !empty($lead->additional_email)): ?> readonly <?php endif; ?>>
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label for="phone">
            <?php echo app('translator')->get('messages.phone'); ?>
        </label>
        <input type="text" name="phone" id="phone" value="<?php if(!empty($lead) && !empty($lead->phone)): ?> <?php echo e($lead->phone); ?> <?php endif; ?>" class="form-control input_number" readonly>
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label for="secondary_phone_key">
            <?php echo app('translator')->get('messages.secondary_phone_key'); ?>
        </label>
        <input type="text" name="secondary_phone" id="secondary_phone_key" value="<?php if(!empty($lead) && !empty($lead->secondary_phone)): ?> <?php echo e($lead->secondary_phone); ?> <?php endif; ?>" class="form-control digit_with_comma" <?php if(!empty($lead) && !empty($lead->secondary_phone)): ?> readonly <?php endif; ?>>
    </div>
</div><?php /**PATH /var/www/html/resources/views/admin/eoi/partials/common_details_of_applicant.blade.php ENDPATH**/ ?>