<?php $__env->startSection('content'); ?>
<div class="row mb-2">
   <div class="col-sm-6">
        <h2>
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.campaign.title_singular')); ?>

        </h2>
   </div>
</div>
<div class="card card-primary card-outline">
    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.campaigns.update", [$campaign->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="campaign_name"><?php echo e(trans('cruds.campaign.fields.campaign_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('campaign_name') ? 'is-invalid' : ''); ?>" type="text" name="campaign_name" id="campaign_name" value="<?php echo e(old('campaign_name', $campaign->campaign_name)); ?>" required>
                <?php if($errors->has('campaign_name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('campaign_name')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.campaign.fields.campaign_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="start_date"><?php echo e(trans('cruds.campaign.fields.start_date')); ?></label>
                <input class="form-control date <?php echo e($errors->has('start_date') ? 'is-invalid' : ''); ?>" type="text" name="start_date" id="start_date" value="<?php echo e(old('start_date', $campaign->start_date)); ?>">
                <?php if($errors->has('start_date')): ?>
                    <span class="text-danger"><?php echo e($errors->first('start_date')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.campaign.fields.start_date_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="end_date"><?php echo e(trans('cruds.campaign.fields.end_date')); ?></label>
                <input class="form-control date <?php echo e($errors->has('end_date') ? 'is-invalid' : ''); ?>" type="text" name="end_date" id="end_date" value="<?php echo e(old('end_date', $campaign->end_date)); ?>">
                <?php if($errors->has('end_date')): ?>
                    <span class="text-danger"><?php echo e($errors->first('end_date')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.campaign.fields.end_date_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="project_id"><?php echo e(trans('cruds.campaign.fields.project')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('project') ? 'is-invalid' : ''); ?>" name="project_id" id="project_id" required>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((old('project_id') ? old('project_id') : $campaign->project->id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('project')): ?>
                    <span class="text-danger"><?php echo e($errors->first('project')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.campaign.fields.project_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="agency_id"><?php echo e(trans('cruds.campaign.fields.agency')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('agency') ? 'is-invalid' : ''); ?>" name="agency_id" id="agency_id">
                    <?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((old('agency_id') ? old('agency_id') : $campaign->agency->id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('agency')): ?>
                    <span class="text-danger"><?php echo e($errors->first('agency')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.campaign.fields.agency_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/campaigns/edit.blade.php ENDPATH**/ ?>