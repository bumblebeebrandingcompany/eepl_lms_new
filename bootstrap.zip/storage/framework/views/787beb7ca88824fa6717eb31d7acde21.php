<?php $__env->startSection('content'); ?>
    <?php if ($__env->exists('admin.leads.partials.header')) echo $__env->make('admin.leads.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if($lead_view == 'list'): ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card card-primary card-outline">
                    <div class="card-body">
                        <?php if ($__env->exists('admin.leads.partials.lead_table.lead_table')) echo $__env->make('admin.leads.partials.lead_table.lead_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
       <?php if ($__env->exists('admin.leads.partials.common_lead_js')) echo $__env->make('admin.leads.partials.common_lead_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/leads/index.blade.php ENDPATH**/ ?>