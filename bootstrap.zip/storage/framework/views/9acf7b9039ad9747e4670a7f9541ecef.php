<?php $__env->startSection('content'); ?>
<div class="row mb-2">
   <div class="col-sm-12">
        <h2>
            <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.source.title_singular')); ?>

        </h2>
   </div>
</div>
<div class="card card-primary card-outline">
    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.sources.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="project_id"><?php echo e(trans('cruds.source.fields.project')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('project') ? 'is-invalid' : ''); ?>" name="project_id" id="project_id" required>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('project_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('project')): ?>
                    <span class="text-danger"><?php echo e($errors->first('project')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.source.fields.project_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="campaign_id"><?php echo e(trans('cruds.source.fields.campaign')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('campaign') ? 'is-invalid' : ''); ?>" name="campaign_id" id="campaign_id" required>
                    <?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('campaign_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('campaign')): ?>
                    <span class="text-danger"><?php echo e($errors->first('campaign')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.source.fields.campaign_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="name"><?php echo e(trans('cruds.source.fields.name')); ?></label>
                <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name" id="name" value="<?php echo e(old('name', '')); ?>" required>
                <?php if($errors->has('name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.source.fields.name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="source_name"><?php echo e(trans('messages.source_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('source_name') ? 'is-invalid' : ''); ?>" type="text" name="source_name" id="source_name" value="<?php echo e(old('source_name')); ?>" required>
                <?php if($errors->has('source_name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('source_name')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('messages.source_name_help_text')); ?></span>
            </div>
            <?php if ($__env->exists('admin.sources.partials.custom_fields')) echo $__env->make('admin.sources.partials.custom_fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(function() {
        function getCampaigns() {
            let data = {
                project_id: $('#project_id').val()
            };
            $.ajax({
                method:"GET",
                url: "<?php echo e(route('admin.get.campaigns')); ?>",
                data: data,
                dataType: "json",
                success: function(response) {
                    $('#campaign_id').select2('destroy').empty().select2({data: response});
                }
            });
        }

        $(document).on('change', '#project_id', function() {
            getCampaigns();
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/sources/create.blade.php ENDPATH**/ ?>