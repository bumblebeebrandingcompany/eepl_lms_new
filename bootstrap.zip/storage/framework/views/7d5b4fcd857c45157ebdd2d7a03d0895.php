<?php $__env->startSection('content'); ?>
<div class="row mb-2">
   <div class="col-sm-6">
        <h2>
            <?php echo e(trans('global.add')); ?> <?php echo e(trans('messages.expression_of_interest')); ?>

        </h2>
   </div>
</div>
<div class="row">
    <div class="col-md-12">
        <form method="POST" action="<?php echo e(route("admin.eoi.store")); ?>" enctype="multipart/form-data" id="eoi">
            <?php echo csrf_field(); ?>
            <?php if ($__env->exists('admin.eoi.partials.form', ['lead' => '', 'event' => ''])) echo $__env->make('admin.eoi.partials.form', ['lead' => '', 'event' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row float-right">
                <div class="col-md-12">
                    <div class="form-group">
                        <button class="btn btn-danger" type="submit">
                            <?php echo e(trans('global.save')); ?>

                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
       <?php if ($__env->exists('admin.eoi.partials.common_js')) echo $__env->make('admin.eoi.partials.common_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/eoi/create.blade.php ENDPATH**/ ?>