@extends('layouts.admin')

@section('content')
    <style>
        .square-card {
            width: 200px; /* Adjust the width as needed */
            height: 200px; /* Adjust the height to match the width for square shape */
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            cursor: pointer; /* Add cursor pointer to indicate clickable */
        }
    </style>

    @if($project->isNotEmpty())
        @foreach($project as $projects)
            <a href="{{ route('admin.booking.create', ['projectId' => $projects->id]) }}">
                <div class="card card-primary card-outline square-card">
                    <div>{{ $projects->name ?? ''}}</div>
                    <div>{{ $projects->location ?? ''}}</div>
                </div>
            </a>
        @endforeach
    @else
        <p>No projects found.</p>
    @endif
@endsection
{{-- <a href="{{ route('admin.leads.show', ['lead' => $leads->id]) }}">
    {{ $leads->ref_num }}
</a> --}}