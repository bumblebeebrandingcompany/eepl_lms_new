<?php $__env->startSection('content'); ?>
<div class="row mb-2">
   <div class="col-sm-6">
        <h2>
            <?php echo e(trans('global.edit')); ?> <?php echo e(trans('messages.document')); ?>

        </h2>
   </div>
</div>
<div class="card card-primary card-outline">
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('admin.documents.update', [$document->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <?php if ($__env->exists('admin.documents.partials.form')) echo $__env->make('admin.documents.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="form-group">
                <button class="btn btn-primary float-right" type="submit">
                    <?php echo e(trans('global.update')); ?>

                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function () {
        function SimpleUploadAdapter(editor) {
            editor.plugins.get('FileRepository').createUploadAdapter = function(loader) {
            return {
                upload: function() {
                return loader.file
                    .then(function (file) {
                    return new Promise(function(resolve, reject) {
                        // Init request
                        var xhr = new XMLHttpRequest();
                        xhr.open('POST', '<?php echo e(route('admin.documents.storeCKEditorImages')); ?>', true);
                        xhr.setRequestHeader('x-csrf-token', window._token);
                        xhr.setRequestHeader('Accept', 'application/json');
                        xhr.responseType = 'json';

                        // Init listeners
                        var genericErrorText = `Couldn't upload file: ${ file.name }.`;
                        xhr.addEventListener('error', function() { reject(genericErrorText) });
                        xhr.addEventListener('abort', function() { reject() });
                        xhr.addEventListener('load', function() {
                        var response = xhr.response;

                        if (!response || xhr.status !== 201) {
                            return reject(response && response.message ? `${genericErrorText}\n${xhr.status} ${response.message}` : `${genericErrorText}\n ${xhr.status} ${xhr.statusText}`);
                        }

                        $('form').append('<input type="hidden" name="ck-media[]" value="' + response.id + '">');

                        resolve({ default: response.url });
                        });

                        if (xhr.upload) {
                        xhr.upload.addEventListener('progress', function(e) {
                            if (e.lengthComputable) {
                            loader.uploadTotal = e.total;
                            loader.uploaded = e.loaded;
                            }
                        });
                        }

                        // Send request
                        var data = new FormData();
                        data.append('upload', file);
                        data.append('crud_id', '<?php echo e($document->id ?? 0); ?>');
                        xhr.send(data);
                    });
                    })
                }
            };
            }
        }

        var allEditors = document.querySelectorAll('.ckeditor');
        for (var i = 0; i < allEditors.length; ++i) {
            ClassicEditor.create(
            allEditors[i], {
                extraPlugins: [SimpleUploadAdapter]
            }
            );
        }

        $(document).on('click', '.remove-file', function(){
            if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
                let url = $(this).attr('data-href');
                let file = $(this).attr('data-file');
                let row = $(this).closest('tr');
                $.ajax({
					method:"DELETE",
					url: url,
					data: {file : file},
					dataType: "json",
					success: function(response) {
						if(response.success == true){
                            if($(row).closest('tbody').find('tr').length <= 1) {
                                $('.existing_files_div').remove();
                            } else{
                                $(row).remove();
                            }
						}
                        alert(response.message);
					}
				});
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/documents/edit.blade.php ENDPATH**/ ?>