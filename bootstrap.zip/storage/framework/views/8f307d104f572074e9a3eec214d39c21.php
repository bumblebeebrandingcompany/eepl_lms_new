<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row mb-2">
        <div class="col-sm-6">
            <h2>
                <?php echo app('translator')->get('messages.lead_activities'); ?>
            </h2>
        </div>
    </div>
    <div class="card card-primary card-outline">
        <div class="card-body">
            <div class="row">
                <div class="col-md-12 mb-3">
                    <div class="form-group">
                        <label for="lead-activity">
                            Api to add lead activity
                        </label>
                        <input type="text" class="form-control" id="lead-activity" 
                            readonly value="<?php echo e(route('webhook.store.lead.activity')); ?>">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <h4><?php echo app('translator')->get('messages.log'); ?></h4>
                </div>
                <div class="col-md-12 mb-2">
                    <form method="get" action="<?php echo e(route('admin.webhook.lead.activities.log')); ?>" enctype="multipart/form-data">
                        <div class="form-group">
                            <div class="input-group">
                                <input type="text" name="search" class="form-control" placeholder="Search on lead activities..." id="lead_activities_response_search" value="<?php echo e($search_text ?? ''); ?>">
                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-secondary search_data">
                                        <?php echo app('translator')->get('messages.search'); ?>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-bordered text-nowrap">
                            <thead>
                                <tr>
                                    <th><?php echo app('translator')->get('messages.created_at'); ?></th>
                                    <th><?php echo app('translator')->get('messages.event_type'); ?></th>
                                    <th><?php echo app('translator')->get('messages.webhook_response'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $leads_activities_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead_activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <?php echo e(\Carbon\Carbon::createFromTimestamp(strtotime($lead_activity->created_at))->format('M d Y h:i A')); ?>

                                        </td>
                                        <td>
                                            <?php echo e(ucfirst(str_replace('_', ' ', $lead_activity->event_type))); ?>

                                        </td>
                                        <td>
                                            <?php if(!empty($lead_activity->webhook_data)): ?>
                                                <?php echo e(json_encode($lead_activity->webhook_data)); ?>

                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="3" class="text-center">
                                            No log found
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php if(!empty($leads_activities_history->links())): ?>
                    <div class="col-md-12 text-right mt-3">
                        <?php echo e($leads_activities_history->links()); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/webhook/lead_activities_log.blade.php ENDPATH**/ ?>