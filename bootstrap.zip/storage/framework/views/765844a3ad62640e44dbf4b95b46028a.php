<?php
    $payload = $event->webhook_data['payload'] ?? [];
?>
<div class="row">
    <div class="col-md-12">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>
                            <?php echo app('translator')->get('messages.key'); ?>
                        </th>
                        <th>
                            <?php echo app('translator')->get('messages.value'); ?>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $payload; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php if(
                            !empty($label) && 
                            !empty($value) &&
                            in_array($label, ['called_on', 'direction', 'duration', 'feedback', 'message', 'notes', 'originator', 'recipient', 'recording', 'status', 'initiated_by'])
                        ): ?>
                            <tr>
                                <td>
                                    <?php echo e(ucfirst(str_replace('_', ' ', $label))); ?>

                                </td>
                                <td>
                                    <?php if(!empty($value) && is_array($value)): ?>
                                        <?php if(in_array($label, ['recording'])): ?>
                                            <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <audio controls>
                                                    <source src="<?php echo e($data); ?>" type="audio/wav">
                                                    Your browser does not support the audio element.
                                                </audio>
                                                <br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($data); ?> <br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php echo e($value ?? ''); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="2" class="text-center">
                                No data found
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div><?php /**PATH /var/www/html/resources/views/admin/leads/partials/event_details/call_feedback_submitted.blade.php ENDPATH**/ ?>