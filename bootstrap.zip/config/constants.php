<?php

return [
    'DOCUMENT_URL' => env('DOCUMENT_URL', env('APP_URL')),
    'document_files_path' => 'files',
];