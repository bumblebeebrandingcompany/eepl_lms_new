<?php
    $details_of_co_applicant = $event->webhook_data['details_of_co_applicant'] ?? [];
?>
<?php if ($__env->exists('admin.bookings.partials.common_details_of_co_applicant')) echo $__env->make('admin.bookings.partials.common_details_of_co_applicant', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="col-md-6">
    <div class="form-group">
        <label for="details_of_co_applicant_sex">
            <?php echo app('translator')->get('messages.gender'); ?>
        </label>
        <select name="details_of_co_applicant[gender]" id="details_of_co_applicant_sex" class="form-control">
            <option value=""><?php echo app('translator')->get('messages.please_select'); ?></option>
            <option value="Male" <?php if(!empty($details_of_co_applicant['gender']) && $details_of_co_applicant['gender'] == 'Male'): ?> selected <?php endif; ?>>Male</option>
            <option value="Female" <?php if(!empty($details_of_co_applicant['gender']) && $details_of_co_applicant['gender'] == 'Female'): ?> selected <?php endif; ?>>Female</option>
        </select>
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label for="details_of_co_applicant_Profession">
            Profession
        </label>
        <input type="text" name="details_of_co_applicant[profession]" id="details_of_co_applicant_Profession" class="form-control"
        value="<?php echo e($details_of_co_applicant['profession'] ?? ''); ?>">
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label for="details_of_co_applicant_Designation">
            Designation
        </label>
        <input type="text" name="details_of_co_applicant[designation]" id="details_of_co_applicant_Designation" class="form-control" value="<?php echo e($details_of_co_applicant['designation'] ?? ''); ?>">
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label for="details_of_co_applicant_company_name">
            <?php echo app('translator')->get('messages.company_name'); ?>
        </label>
        <input type="text" name="details_of_co_applicant[company_name]" id="details_of_co_applicant_company_name" class="form-control"
        value="<?php echo e($details_of_co_applicant['company_name'] ?? ''); ?>">
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label for="details_of_co_applicant_residential_status">
            <?php echo app('translator')->get('messages.residential_status'); ?>
        </label>
        <select name="details_of_co_applicant[residential_status]" id="details_of_co_applicant_residential_status" class="form-control">
            <option value=""><?php echo app('translator')->get('messages.please_select'); ?></option>
            <option value="Resident" <?php if(!empty($details_of_co_applicant['residential_status']) && $details_of_co_applicant['residential_status'] == 'Resident'): ?> selected <?php endif; ?>>Resident</option>
            <option value="NRI" <?php if(!empty($details_of_co_applicant['residential_status']) && $details_of_co_applicant['residential_status'] == 'NRI'): ?> selected <?php endif; ?>>NRI</option>
        </select>
    </div>
</div>
<div class="col-md-12">
    <div class="form-group">
        <label for="details_of_co_applicant_Correspondence_Address">
            Correspondence Address
        </label>
        <textarea name="details_of_co_applicant[correspondence_address]" id="details_of_co_applicant_Correspondence_Address" class="form-control" cols="2"><?php echo $details_of_co_applicant['correspondence_address'] ?? ''; ?></textarea>
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label for="details_of_co_applicant_pan">
            <?php echo app('translator')->get('messages.pan'); ?>
        </label>
        <input type="text" name="details_of_co_applicant[pan]" id="details_of_co_applicant_pan" class="form-control"
            value="<?php echo e($details_of_co_applicant['pan'] ?? ''); ?>">
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label for="details_of_co_applicant_age">
            Age
        </label>
        <input type="text" name="details_of_co_applicant[age]" id="details_of_co_applicant_age" class="form-control co_applicant_age"  value="<?php echo e($details_of_co_applicant['age'] ?? ''); ?>">
    </div>
</div>
<?php /**PATH /var/www/html/resources/views/admin/bookings/partials/basic_common_details_of_co_applicant.blade.php ENDPATH**/ ?>