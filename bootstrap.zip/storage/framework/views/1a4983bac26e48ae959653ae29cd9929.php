<div class="col-md-6">
    <div class="form-group">
        <label for="co_applicant_name">
            <?php echo app('translator')->get('messages.name'); ?>
        </label>
        <input type="text" name="details_of_co_applicant[name]" id="co_applicant_name" class="form-control"
            value="<?php echo e($details_of_co_applicant['name'] ?? ''); ?>">
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label for="co_applicant_email">
            <?php echo app('translator')->get('messages.email'); ?>
        </label>
        <input type="email" name="details_of_co_applicant[email]" id="co_applicant_email" class="form-control"
            value="<?php echo e($details_of_co_applicant['email'] ?? ''); ?>">
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label for="co_applicant_additional_email_key">
            <?php echo app('translator')->get('messages.additional_email_key'); ?>
        </label>
        <input type="email" name="details_of_co_applicant[additional_email]" id="co_applicant_additional_email_key"  class="form-control" value="<?php echo e($details_of_co_applicant['additional_email'] ?? ''); ?>">
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label for="co_applicant_phone">
            <?php echo app('translator')->get('messages.phone'); ?>
        </label>
        <input type="text" name="details_of_co_applicant[phone]" id="co_applicant_phone" class="form-control input_number"
        value="<?php echo e($details_of_co_applicant['phone'] ?? ''); ?>">
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label for="co_applicant_secondary_phone_key">
            <?php echo app('translator')->get('messages.secondary_phone_key'); ?>
        </label>
        <input type="text" name="details_of_co_applicant[secondary_phone]" id="co_applicant_secondary_phone_key" class="form-control input_number" value="<?php echo e($details_of_co_applicant['secondary_phone'] ?? ''); ?>">
    </div>
</div><?php /**PATH /var/www/html/resources/views/admin/bookings/partials/common_details_of_co_applicant.blade.php ENDPATH**/ ?>