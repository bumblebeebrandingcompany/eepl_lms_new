<div class="m-3">
    <div class="card">
        <div class="card-header">
            <?php if(auth()->user()->is_superadmin): ?>
                <a class="btn btn-success float-right" href="<?php echo e(route('admin.projects.create')); ?>">
                    <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.project.title_singular')); ?>

                </a>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class=" table table-bordered table-striped table-hover datatable datatable-clientProjects">
                    <thead>
                        <tr>
                            <th width="10">

                            </th>
                            <th>
                                <?php echo e(trans('cruds.project.fields.name')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.project.fields.start_date')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.project.fields.end_date')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.project.fields.created_by')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.project.fields.client')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.client.fields.email')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.project.fields.location')); ?>

                            </th>
                            <th>
                                &nbsp;
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr data-entry-id="<?php echo e($project->id); ?>">
                                <td>

                                </td>
                                <td>
                                    <?php echo e($project->name ?? ''); ?>

                                </td>
                                <td>
                                    <?php echo e($project->start_date ?? ''); ?>

                                </td>
                                <td>
                                    <?php echo e($project->end_date ?? ''); ?>

                                </td>
                                <td>
                                    <?php echo e($project->created_by->name ?? ''); ?>

                                </td>
                                <td>
                                    <?php echo e($project->client->name ?? ''); ?>

                                </td>
                                <td>
                                    <?php echo e($project->client->email ?? ''); ?>

                                </td>
                                <td>
                                    <?php echo e($project->location ?? ''); ?>

                                </td>
                                <td>
                                    <?php if(auth()->user()->is_superadmin): ?>
                                        <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.projects.show', $project->id)); ?>">
                                            <?php echo e(trans('global.view')); ?>

                                        </a>
                                    <?php endif; ?>

                                    <?php if(auth()->user()->is_superadmin): ?>
                                        <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.projects.edit', $project->id)); ?>">
                                            <?php echo e(trans('global.edit')); ?>

                                        </a>
                                    <?php endif; ?>

                                    <?php if(auth()->user()->is_superadmin): ?>
                                        <form action="<?php echo e(route('admin.projects.destroy', $project->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                            <input type="hidden" name="_method" value="DELETE">
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <input type="submit" class="btn btn-xs btn-danger" value="<?php echo e(trans('global.delete')); ?>">
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
  <?php if(auth()->user()->is_superadmin): ?>
  let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "<?php echo e(route('admin.projects.massDestroy')); ?>",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

        return
      }

      if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
<?php endif; ?>

  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  let table = $('.datatable-clientProjects:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
<?php $__env->stopSection(); ?><?php /**PATH /var/www/html/resources/views/admin/clients/relationships/clientProjects.blade.php ENDPATH**/ ?>