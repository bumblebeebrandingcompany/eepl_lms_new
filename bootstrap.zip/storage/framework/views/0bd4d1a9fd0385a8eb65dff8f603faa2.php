<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h1>Edit CpLead</h1>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.cp-leads.update', $cpLead->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?> <!-- Add this line for the update method -->

                        <div class="form-group">
                            <label for="name">Name:</label>
                            <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $cpLead->name)); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="project_id"><?php echo e(trans('cruds.lead.fields.project')); ?></label>
                            <select class="form-control select2 <?php echo e($errors->has('project_id') ? 'is-invalid' : ''); ?>"
                                name="project_id" id="project_id" required>
                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>" <?php echo e(old('project_id', $cpLead->project_id) == $id ? 'selected' : ''); ?>>
                                        <?php echo e($entry); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('project_id')): ?>
                                <span class="text-danger"><?php echo e($errors->first('project_id')); ?></span>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.lead.fields.project_helper')); ?></span>
                        </div>

                        <div class="form-group">
                            <label for="phone">Phone:</label>
                            <input type="text" name="phone" id="phone" class="form-control input_number"
                                value="<?php echo e(old('phone', $cpLead->phone)); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="text" name="email" class="form-control" value="<?php echo e(old('email', $cpLead->email)); ?>" required>
                        </div>

                        <button type="submit" class="btn btn-success">Update CpLead</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/cpleads/edit.blade.php ENDPATH**/ ?>