<div class="row">
    <div class="col-md-12">
        <?php if(count($lead_events) > 0): ?>
            <div class="timeline">
                <?php $__currentLoopData = $lead_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="time-label">
                        <span class="text-center <?php if($event->event_type == 'call_feedback_submitted'): ?>
                                    bg-primary
                                <?php elseif($event->event_type == 'sitevisit_scheduled'): ?>
                                    bg-warning
                                <?php elseif($event->event_type == 'sitevisit_conducted'): ?>
                                    bg-success
                                <?php elseif($event->event_type == 'stage_changed'): ?>
                                    bg-danger
                                <?php elseif($event->event_type == 'followup_scheduled'): ?>
                                    bg-warning
                                <?php elseif($event->event_type == 'followup_conducted'): ?>
                                    bg-success
                                <?php elseif($event->event_type == 'note_added'): ?>
                                    bg-info
                                <?php elseif($event->event_type == 'document_sent'): ?>
                                    bg-dark
                                <?php elseif($event->event_type == 'expression_of_interest'): ?>
                                    bg-success
                                <?php elseif($event->event_type == 'lead_updated'): ?>
                                    bg-info
                                <?php elseif($event->event_type == 'lead_requirement_updated'): ?>
                                    bg-olive
                                <?php else: ?>
                                    bg-olive
                                <?php endif; ?>">
                            <?php echo e(\Carbon\Carbon::createFromTimestamp(strtotime($event->added_at))->format('M d Y h:i A')); ?>

                            <br>
                            <small>(<?php echo e(\Carbon\Carbon::createFromTimestamp(strtotime($event->added_at))->diffForHumans()); ?>)</small>
                        </span>
                    </div>
                    <div>
                        <?php if($event->event_type == 'call_feedback_submitted'): ?>
                            <i class="fas fa-phone-volume bg-blue"></i>
                        <?php elseif($event->event_type == 'sitevisit_scheduled'): ?>
                            <i class="fas fa-map-marker-alt bg-yellow"></i>
                        <?php elseif($event->event_type == 'sitevisit_conducted'): ?>
                            <i class="fas fa-map-marker bg-green"></i>
                        <?php elseif($event->event_type == 'stage_changed'): ?>
                            <i class="fas fa-exchange-alt bg-red"></i>
                        <?php elseif($event->event_type == 'followup_scheduled'): ?>
                            <i class="fas fa-bullseye bg-yellow"></i>
                        <?php elseif($event->event_type == 'followup_conducted'): ?>
                            <i class="fas fa-certificate bg-green"></i>
                        <?php elseif($event->event_type == 'note_added'): ?>
                            <i class="far fa-sticky-note bg-info"></i>
                        <?php elseif($event->event_type == 'document_sent'): ?>
                            <i class="fas fa-file-alt bg-dark"></i>
                        <?php elseif($event->event_type == 'expression_of_interest'): ?>
                            <i class="fas fa-wind bg-success"></i>
                        <?php elseif($event->event_type == 'lead_updated'): ?>
                            <i class="fas fa-user-edit bg-info"></i>
                        <?php elseif($event->event_type == 'lead_requirement_updated'): ?>
                            <i class="fas fa-pen-square bg-olive"></i>
                        <?php else: ?>
                            <i class="far fa-check-circle bg-olive"></i>
                        <?php endif; ?>
                        <div class="timeline-item">
                            <span class="time">
                                <i class="fas fa-clock"></i>
                                <?php echo e(\Carbon\Carbon::createFromTimestamp(strtotime($event->added_at))->format('h:i A')); ?>

                            </span>
                            <h3 class="timeline-header text-bold <?php if($event->event_type == 'call_feedback_submitted'): ?>
                                    text-primary
                                <?php elseif($event->event_type == 'sitevisit_scheduled'): ?>
                                    text-warning
                                <?php elseif($event->event_type == 'sitevisit_conducted'): ?>
                                    text-success
                                <?php elseif($event->event_type == 'stage_changed'): ?>
                                    text-danger
                                <?php elseif($event->event_type == 'followup_scheduled'): ?>
                                    text-warning
                                <?php elseif($event->event_type == 'followup_conducted'): ?>
                                    text-success
                                <?php elseif($event->event_type == 'note_added'): ?>
                                    text-info
                                <?php elseif($event->event_type == 'document_sent'): ?>
                                    text-dark
                                <?php elseif($event->event_type == 'expression_of_interest'): ?>
                                    text-success
                                <?php elseif($event->event_type == 'lead_updated'): ?>
                                    text-info
                                <?php elseif($event->event_type == 'lead_requirement_updated'): ?>
                                    text-olive
                                <?php else: ?>
                                    text-olive
                                <?php endif; ?>">
                                <?php echo e(ucfirst(str_replace('_', ' ', $event->event_type))); ?>

                                <small class="text-muted">
                                    (
                                        <?php echo e(ucfirst(str_replace('_', ' ', $event->source))); ?>

                                    )
                                </small>
                            </h3>
                            <div class="timeline-body">
                            <?php if($event->event_type == 'call_feedback_submitted'): ?>
                                <?php if ($__env->exists('admin.leads.partials.event_details.call_feedback_submitted')) echo $__env->make('admin.leads.partials.event_details.call_feedback_submitted', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php elseif($event->event_type == 'sitevisit_scheduled'): ?>
                                <?php if ($__env->exists('admin.leads.partials.event_details.sitevisit')) echo $__env->make('admin.leads.partials.event_details.sitevisit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php elseif($event->event_type == 'sitevisit_conducted'): ?>
                                <?php if ($__env->exists('admin.leads.partials.event_details.sitevisit')) echo $__env->make('admin.leads.partials.event_details.sitevisit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php elseif($event->event_type == 'stage_changed'): ?>
                                <?php if ($__env->exists('admin.leads.partials.event_details.stage_changed')) echo $__env->make('admin.leads.partials.event_details.stage_changed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php elseif($event->event_type == 'followup_scheduled'): ?>
                                <?php if ($__env->exists('admin.leads.partials.event_details.followup')) echo $__env->make('admin.leads.partials.event_details.followup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php elseif($event->event_type == 'followup_conducted'): ?>
                                <?php if ($__env->exists('admin.leads.partials.event_details.followup')) echo $__env->make('admin.leads.partials.event_details.followup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php elseif($event->event_type == 'note_added'): ?>
                                <?php if ($__env->exists('admin.leads.partials.event_details.note_added')) echo $__env->make('admin.leads.partials.event_details.note_added', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php elseif($event->event_type == 'document_sent'): ?>
                                <?php if ($__env->exists('admin.leads.partials.event_details.document_sent')) echo $__env->make('admin.leads.partials.event_details.document_sent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php elseif($event->event_type == 'expression_of_interest'): ?>
                                <?php if ($__env->exists('admin.leads.partials.event_details.expression_of_interest', ['enable_header' => true])) echo $__env->make('admin.leads.partials.event_details.expression_of_interest', ['enable_header' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php elseif($event->event_type == 'lead_updated'): ?>
                                <?php if ($__env->exists('admin.leads.partials.event_details.lead_updated')) echo $__env->make('admin.leads.partials.event_details.lead_updated', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php elseif($event->event_type == 'lead_requirement_updated'): ?>
                                <?php if ($__env->exists('admin.leads.partials.event_details.lead_requirement_updated')) echo $__env->make('admin.leads.partials.event_details.lead_requirement_updated', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php else: ?>
                                <?php echo e(json_encode($event->webhook_data ?? [])); ?>

                            <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <div class="callout callout-warning">
                <h5>No, record found.</h5>
            </div>
        <?php endif; ?>
    </div>
</div><?php /**PATH /var/www/html/resources/views/admin/leads/partials/timeline.blade.php ENDPATH**/ ?>