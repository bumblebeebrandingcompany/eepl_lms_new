<div class="form-group">
    <label for="project_id"><?php echo e(trans('cruds.lead.fields.project')); ?></label>
    <select class="form-control select2" name="project_id" id="project_id">
        <option value=""><?php echo app('translator')->get('messages.please_select'); ?></option>
        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($id); ?>" 
            <?php if(
                (
                    old('project_id') == $id
                ) ||
                (
                    !empty($document->project_id) &&
                    ($document->project_id == $id)
                )
            ): ?>
                selected
            <?php endif; ?>
            >
                <?php echo e($entry); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="form-group">
    <label for="title" class="required">
        <?php echo app('translator')->get('messages.title'); ?>
    </label>
    <input type="text" name="title" id="title" value="<?php echo e($document->title ?? old('title', '')); ?>" class="form-control <?php echo e($errors->has('title') ? 'is-invalid' : ''); ?>" required>
    <?php if($errors->has('title')): ?>
        <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
    <?php endif; ?>
</div>
<div class="form-group">
    <label for="details"><?php echo e(trans('messages.details')); ?></label>
    <textarea name="details" class="form-control ckeditor <?php echo e($errors->has('details') ? 'is-invalid' : ''); ?>" id="details" rows="2"><?php echo $document->details ?? old('details', ''); ?></textarea>
    <?php if($errors->has('details')): ?>
        <span class="text-danger"><?php echo e($errors->first('details')); ?></span>
    <?php endif; ?>
</div>
<?php if ($__env->exists('admin.documents.partials.files')) echo $__env->make('admin.documents.partials.files', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/documents/partials/form.blade.php ENDPATH**/ ?>